import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useWeb3Store } from "@/store/web3Store";
import { Wallet, ExternalLink, X } from "lucide-react";

interface WalletModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function WalletModal({ isOpen, onClose }: WalletModalProps) {
  const { connectWallet, isConnecting, error } = useWeb3Store();
  const [selectedWallet, setSelectedWallet] = useState<string | null>(null);

  const walletOptions = [
    {
      id: "metamask",
      name: "MetaMask",
      description: "Connect using browser extension",
      icon: "🦊",
      color: "bg-orange-500",
    },
    {
      id: "walletconnect",
      name: "WalletConnect",
      description: "Scan with WalletConnect to connect",
      icon: "📱",
      color: "bg-blue-500",
    },
    {
      id: "coinbase",
      name: "Coinbase Wallet",
      description: "Connect with Coinbase Wallet",
      icon: "🪙",
      color: "bg-blue-600",
    },
  ];

  const handleWalletSelect = async (walletId: string) => {
    setSelectedWallet(walletId);
    
    try {
      await connectWallet();
      onClose();
    } catch (error) {
      setSelectedWallet(null);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md bg-surface-dark border-cyan-400/30">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-2xl font-cyber text-cyan-400">
              Connect Wallet
            </DialogTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="text-gray-400 hover:text-white"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
          <p className="text-gray-400">
            Choose your preferred wallet to connect to BUChain
          </p>
        </DialogHeader>

        <div className="space-y-4 mt-6">
          {walletOptions.map((wallet) => (
            <Button
              key={wallet.id}
              variant="outline"
              className="w-full flex items-center space-x-4 p-4 bg-surface-blue/30 hover:bg-surface-blue/50 border-transparent hover:border-cyan-400/30 transition-all duration-300 h-auto"
              onClick={() => handleWalletSelect(wallet.id)}
              disabled={isConnecting && selectedWallet === wallet.id}
            >
              <div className={`w-10 h-10 ${wallet.color} rounded-lg flex items-center justify-center text-white text-xl`}>
                {wallet.icon}
              </div>
              <div className="text-left flex-1">
                <div className="font-bold text-white">{wallet.name}</div>
                <div className="text-sm text-gray-400">{wallet.description}</div>
              </div>
              {isConnecting && selectedWallet === wallet.id && (
                <div className="w-4 h-4 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
              )}
            </Button>
          ))}
        </div>

        {error && (
          <div className="mt-4 p-3 bg-red-500/10 border border-red-500/30 rounded-lg">
            <p className="text-sm text-red-400">{error}</p>
          </div>
        )}

        <div className="mt-6 pt-6 border-t border-gray-700 text-center">
          <p className="text-sm text-gray-400 mb-4">New to wallets?</p>
          <Button
            variant="link"
            className="text-cyan-400 hover:text-white transition-colors duration-300"
          >
            Learn more about wallets <ExternalLink className="ml-1 h-3 w-3" />
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
