import { useWeb3Store } from "@/store/web3Store";
import { CyberButton } from "@/components/ui/cyber-button";
import { Wallet, LogOut, ChevronDown } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";

export function WalletConnect() {
  const { 
    isConnected, 
    isConnecting, 
    walletInfo, 
    connectWallet, 
    disconnectWallet,
    switchNetwork,
    error 
  } = useWeb3Store();

  const formatAddress = (address: string) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  const formatBalance = (balance: string) => {
    return `${parseFloat(balance).toFixed(4)} ETH`;
  };

  const getNetworkColor = (chainId: number) => {
    switch (chainId) {
      case 1: return "bg-blue-500";
      case 137: return "bg-purple-500";
      case 56: return "bg-yellow-500";
      default: return "bg-gray-500";
    }
  };

  const getNetworkName = (chainId: number) => {
    switch (chainId) {
      case 1: return "Ethereum";
      case 137: return "Polygon";
      case 56: return "BSC";
      default: return "Unknown";
    }
  };

  if (!isConnected) {
    return (
      <CyberButton
        onClick={connectWallet}
        disabled={isConnecting}
        variant="cyber-primary"
        glowEffect
      >
        <Wallet className="mr-2 h-4 w-4" />
        {isConnecting ? "Connecting..." : "Connect Wallet"}
      </CyberButton>
    );
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <div className="flex items-center space-x-3 bg-surface-blue/50 rounded-lg px-3 py-2 cursor-pointer hover:bg-surface-blue/70 transition-colors duration-300">
          <Avatar className="h-8 w-8">
            <AvatarFallback className="bg-gradient-to-br from-cyan-400 to-purple-500 text-white text-xs">
              {walletInfo?.address.slice(2, 4).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div className="hidden sm:block">
            <div className="text-sm font-medium text-white">
              {formatAddress(walletInfo?.address || "")}
            </div>
            <div className="text-xs text-gray-400">
              {formatBalance(walletInfo?.balance || "0")}
            </div>
          </div>
          <Badge 
            className={`${getNetworkColor(walletInfo?.chainId || 1)} text-white text-xs`}
          >
            {getNetworkName(walletInfo?.chainId || 1)}
          </Badge>
          <ChevronDown className="h-4 w-4 text-gray-400" />
        </div>
      </DropdownMenuTrigger>
      
      <DropdownMenuContent className="w-56 bg-surface-dark border-cyan-400/30">
        <div className="px-2 py-1.5">
          <div className="text-sm font-medium text-cyan-400">
            {formatAddress(walletInfo?.address || "")}
          </div>
          <div className="text-xs text-gray-400">
            Balance: {formatBalance(walletInfo?.balance || "0")}
          </div>
        </div>
        
        <DropdownMenuSeparator className="bg-gray-700" />
        
        <DropdownMenuItem 
          onClick={() => switchNetwork(1)}
          className="text-white hover:bg-surface-blue/50"
        >
          <div className="w-3 h-3 bg-blue-500 rounded-full mr-2"></div>
          Ethereum
        </DropdownMenuItem>
        
        <DropdownMenuItem 
          onClick={() => switchNetwork(137)}
          className="text-white hover:bg-surface-blue/50"
        >
          <div className="w-3 h-3 bg-purple-500 rounded-full mr-2"></div>
          Polygon
        </DropdownMenuItem>
        
        <DropdownMenuItem 
          onClick={() => switchNetwork(56)}
          className="text-white hover:bg-surface-blue/50"
        >
          <div className="w-3 h-3 bg-yellow-500 rounded-full mr-2"></div>
          Binance Smart Chain
        </DropdownMenuItem>
        
        <DropdownMenuSeparator className="bg-gray-700" />
        
        <DropdownMenuItem 
          onClick={disconnectWallet}
          className="text-red-400 hover:bg-red-500/10"
        >
          <LogOut className="mr-2 h-4 w-4" />
          Disconnect
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
