import { cn } from "@/lib/utils";

interface GlitchTextProps {
  text: string;
  className?: string;
  dataText?: string;
  animate?: boolean;
}

export function GlitchText({ 
  text, 
  className, 
  dataText, 
  animate = true 
}: GlitchTextProps) {
  return (
    <span 
      className={cn(
        "relative inline-block",
        animate && "glitch-text animate-neon-pulse",
        className
      )}
      data-text={dataText || text}
    >
      {text}
    </span>
  );
}
