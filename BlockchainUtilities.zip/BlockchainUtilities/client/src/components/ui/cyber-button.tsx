import { Button, ButtonProps } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { ReactNode } from "react";

interface CyberButtonProps extends ButtonProps {
  variant?: "cyber-primary" | "cyber-secondary" | "cyber-outline" | "cyber-ghost";
  glowEffect?: boolean;
  children: ReactNode;
}

export function CyberButton({ 
  variant = "cyber-primary",
  glowEffect = false,
  className,
  children,
  ...props 
}: CyberButtonProps) {
  const baseClasses = "font-bold transition-all duration-300 transform hover:scale-105";
  
  const variantClasses = {
    "cyber-primary": "bg-gradient-to-r from-cyan-400 to-cyan-500 text-black hover:shadow-cyber-strong",
    "cyber-secondary": "bg-gradient-to-r from-pink-500 to-purple-500 text-white hover:shadow-magenta",
    "cyber-outline": "border-2 border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-black",
    "cyber-ghost": "text-cyan-400 hover:bg-cyan-400/10",
  };

  return (
    <Button
      className={cn(
        baseClasses,
        variantClasses[variant],
        glowEffect && "shadow-cyber",
        className
      )}
      {...props}
    >
      {children}
    </Button>
  );
}
