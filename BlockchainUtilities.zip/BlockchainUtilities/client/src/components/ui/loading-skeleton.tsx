import { cn } from "@/lib/utils";

interface LoadingSkeletonProps {
  className?: string;
  width?: string;
  height?: string;
  rounded?: boolean;
}

export function LoadingSkeleton({ 
  className, 
  width = "100%", 
  height = "1rem",
  rounded = true 
}: LoadingSkeletonProps) {
  return (
    <div
      className={cn(
        "loading-skeleton",
        rounded && "rounded-md",
        className
      )}
      style={{ width, height }}
    />
  );
}

export function NFTCardSkeleton() {
  return (
    <div className="bg-surface-blue/30 rounded-xl overflow-hidden">
      <LoadingSkeleton height="12rem" rounded={false} />
      <div className="p-4 space-y-3">
        <LoadingSkeleton height="1.25rem" />
        <LoadingSkeleton height="1rem" width="75%" />
        <div className="flex justify-between items-center">
          <LoadingSkeleton height="1.5rem" width="5rem" />
          <LoadingSkeleton height="2rem" width="4rem" />
        </div>
      </div>
    </div>
  );
}

export function AuctionCardSkeleton() {
  return (
    <div className="bg-gradient-to-br from-surface-dark to-surface-blue rounded-xl overflow-hidden">
      <LoadingSkeleton height="12rem" rounded={false} />
      <div className="p-5 space-y-3">
        <LoadingSkeleton height="1.25rem" />
        <LoadingSkeleton height="0.875rem" width="60%" />
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <LoadingSkeleton height="1rem" width="4rem" />
            <LoadingSkeleton height="1.5rem" width="4rem" />
          </div>
          <div className="flex justify-between items-center">
            <LoadingSkeleton height="1rem" width="3rem" />
            <LoadingSkeleton height="1rem" width="5rem" />
          </div>
          <LoadingSkeleton height="2.5rem" />
        </div>
      </div>
    </div>
  );
}
