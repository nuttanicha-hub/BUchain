import { Card, CardContent } from "@/components/ui/card";
import { CyberButton } from "@/components/ui/cyber-button";
import { Badge } from "@/components/ui/badge";
import { Clock, Gavel, Heart, TrendingUp } from "lucide-react";
import { Auction, NFT } from "@shared/schema";
import { useState, useEffect } from "react";
import { useAuctionStore } from "@/store/auctionStore";

interface AuctionCardProps {
  auction: Auction & {
    nft: NFT & {
      creator?: { username: string };
    };
    highestBidder?: { username: string };
  };
  onPlaceBid?: (auctionId: number, amount: string) => void;
  onFavorite?: (nftId: number) => void;
  isFavorited?: boolean;
}

export function AuctionCard({ 
  auction, 
  onPlaceBid, 
  onFavorite, 
  isFavorited = false 
}: AuctionCardProps) {
  const [timeLeft, setTimeLeft] = useState<string>("");
  const [imageLoaded, setImageLoaded] = useState(false);
  const { joinAuction, leaveAuction, getAuction } = useAuctionStore();

  // Calculate time left
  useEffect(() => {
    const calculateTimeLeft = () => {
      const endTime = new Date(auction.endTime).getTime();
      const now = new Date().getTime();
      const difference = endTime - now;

      if (difference > 0) {
        const hours = Math.floor(difference / (1000 * 60 * 60));
        const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((difference % (1000 * 60)) / 1000);
        
        setTimeLeft(`${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`);
      } else {
        setTimeLeft("ENDED");
      }
    };

    calculateTimeLeft();
    const timer = setInterval(calculateTimeLeft, 1000);

    return () => clearInterval(timer);
  }, [auction.endTime]);

  // Join auction room for real-time updates
  useEffect(() => {
    joinAuction(auction.id);
    return () => leaveAuction(auction.id);
  }, [auction.id, joinAuction, leaveAuction]);

  // Get real-time auction data
  const liveAuction = getAuction(auction.id);
  const currentBid = liveAuction?.currentBid || auction.currentBid || auction.startPrice;

  const handlePlaceBid = () => {
    if (onPlaceBid) {
      const nextBid = (parseFloat(currentBid) + 0.1).toFixed(3);
      onPlaceBid(auction.id, nextBid);
    }
  };

  const handleFavorite = () => {
    if (onFavorite) onFavorite(auction.nft.id);
  };

  const formatPrice = (price: string) => {
    return `${parseFloat(price).toFixed(3)} ETH`;
  };

  const getAuctionTypeColor = (type: string) => {
    switch (type) {
      case "english": return "bg-green-500";
      case "dutch": return "bg-blue-500";
      default: return "bg-gray-500";
    }
  };

  const isEnded = timeLeft === "ENDED";
  const isActive = auction.isActive && !isEnded;

  return (
    <Card className="bg-gradient-to-br from-surface-dark to-surface-blue border-gray-700 rounded-xl overflow-hidden nft-card group relative">
      {/* Live indicator */}
      {isActive && (
        <div className="absolute top-4 right-4 z-10">
          <Badge className="bg-pink-500 text-white text-xs flex items-center">
            <div className="w-2 h-2 bg-white rounded-full mr-2 animate-pulse"></div>
            LIVE
          </Badge>
        </div>
      )}

      <div className="relative">
        {!imageLoaded && (
          <div className="w-full h-48 bg-gray-800 animate-pulse flex items-center justify-center">
            <div className="text-gray-600">Loading...</div>
          </div>
        )}
        
        <img
          src={auction.nft.image}
          alt={auction.nft.name}
          className={`w-full h-48 object-cover transition-opacity duration-300 ${
            imageLoaded ? "opacity-100" : "opacity-0"
          }`}
          onLoad={() => setImageLoaded(true)}
          onError={() => setImageLoaded(true)}
        />
        
        <div className="absolute top-3 left-3 flex gap-2">
          <Badge className={`${getAuctionTypeColor(auction.type)} text-white text-xs`}>
            {auction.type.toUpperCase()}
          </Badge>
        </div>

        <div className="absolute top-3 right-3 mr-16">
          <button
            onClick={handleFavorite}
            className={`p-2 rounded-full backdrop-blur-sm transition-all duration-300 ${
              isFavorited 
                ? "bg-red-500/80 text-white" 
                : "bg-black/50 text-gray-300 hover:text-red-400"
            }`}
          >
            <Heart className="h-4 w-4" fill={isFavorited ? "currentColor" : "none"} />
          </button>
        </div>
      </div>

      <CardContent className="p-5">
        <div className="space-y-3">
          <div>
            <h3 className="font-bold text-cyan-400 text-lg truncate">
              {auction.nft.name}
            </h3>
            <p className="text-sm text-gray-400">
              by {auction.nft.creator?.username || "Unknown"}
            </p>
          </div>

          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-400">Current Bid</span>
              <div className="text-right">
                <div className="text-lg font-bold text-cyan-400">
                  {formatPrice(currentBid)}
                </div>
                <div className="text-xs text-gray-400">
                  ~${(parseFloat(currentBid) * 1800).toFixed(0)} USD
                </div>
              </div>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-400 flex items-center">
                <Clock className="h-3 w-3 mr-1" />
                {isEnded ? "Ended" : "Ends in"}
              </span>
              <span className={`text-sm font-mono ${
                isEnded ? "text-red-400" : "text-pink-400 auction-timer"
              }`}>
                {timeLeft}
              </span>
            </div>

            {auction.reservePrice && (
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-400">Reserve</span>
                <span className="text-sm text-yellow-400">
                  {formatPrice(auction.reservePrice)}
                </span>
              </div>
            )}

            {auction.highestBidder && (
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-400">Leading Bidder</span>
                <span className="text-sm text-green-400">
                  {auction.highestBidder.username}
                </span>
              </div>
            )}
          </div>

          <div className="flex space-x-2 mt-4">
            <CyberButton
              className="flex-1"
              variant="cyber-primary"
              onClick={handlePlaceBid}
              disabled={!isActive}
            >
              <Gavel className="h-4 w-4 mr-2" />
              {isEnded ? "Auction Ended" : "Place Bid"}
            </CyberButton>
            
            <button className="p-2 border border-cyan-400 text-cyan-400 rounded-lg hover:bg-cyan-400 hover:text-black transition-all duration-300">
              <TrendingUp className="h-4 w-4" />
            </button>
          </div>

          {isActive && (
            <div className="text-xs text-gray-400 text-center">
              Next minimum bid: {formatPrice((parseFloat(currentBid) + 0.1).toFixed(3))}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
