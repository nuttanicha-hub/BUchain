import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { CyberButton } from "@/components/ui/cyber-button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Upload, Image, Loader2, CheckCircle } from "lucide-react";
import { pinataService } from "@/lib/pinata";
import { web3Service } from "@/lib/web3";
import { useWeb3Store } from "@/store/web3Store";
import { useToast } from "@/hooks/use-toast";

const createNFTSchema = z.object({
  name: z.string().min(1, "Name is required").max(100, "Name too long"),
  description: z.string().max(1000, "Description too long").optional(),
  category: z.string().min(1, "Category is required"),
  chain: z.string().min(1, "Chain is required"),
  price: z.string().min(0.001, "Price must be at least 0.001 ETH"),
  royalty: z.number().min(0).max(10, "Royalty must be between 0-10%"),
  enableAffiliate: z.boolean(),
  affiliateCommission: z.number().min(1).max(50).optional(),
  affiliateUrl: z.string().url().optional(),
});

type CreateNFTForm = z.infer<typeof createNFTSchema>;

interface CreateNFTFormProps {
  onSuccess?: (nft: any) => void;
}

export function CreateNFTForm({ onSuccess }: CreateNFTFormProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string>("");
  const [uploading, setUploading] = useState(false);
  const [minting, setMinting] = useState(false);
  const [gasEstimate, setGasEstimate] = useState<string>("0.012");
  
  const { isConnected, walletInfo } = useWeb3Store();
  const { toast } = useToast();

  const form = useForm<CreateNFTForm>({
    resolver: zodResolver(createNFTSchema),
    defaultValues: {
      name: "",
      description: "",
      category: "business-tools",
      chain: "ethereum",
      price: "1.0",
      royalty: 2.5,
      enableAffiliate: false,
      affiliateCommission: 15,
      affiliateUrl: "",
    },
  });

  const watchEnableAffiliate = form.watch("enableAffiliate");

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 100 * 1024 * 1024) { // 100MB limit
        toast({
          title: "File too large",
          description: "Please select a file smaller than 100MB",
          variant: "destructive",
        });
        return;
      }

      setSelectedFile(file);
      const reader = new FileReader();
      reader.onload = () => setPreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const uploadToIPFS = async (file: File) => {
    try {
      setUploading(true);
      const imageUrl = await pinataService.uploadFile(file);
      return imageUrl;
    } catch (error) {
      console.error("Failed to upload to IPFS:", error);
      throw new Error("Failed to upload image to IPFS");
    } finally {
      setUploading(false);
    }
  };

  const onSubmit = async (data: CreateNFTForm) => {
    if (!isConnected) {
      toast({
        title: "Wallet not connected",
        description: "Please connect your wallet to create an NFT",
        variant: "destructive",
      });
      return;
    }

    if (!selectedFile) {
      toast({
        title: "No file selected",
        description: "Please select an image or video file",
        variant: "destructive",
      });
      return;
    }

    try {
      setMinting(true);

      // Upload file to IPFS
      toast({
        title: "Uploading to IPFS",
        description: "Your file is being uploaded to IPFS...",
      });
      
      const imageUrl = await uploadToIPFS(selectedFile);

      // Create metadata
      const metadata = {
        name: data.name,
        description: data.description || "",
        image: imageUrl,
        attributes: [
          { trait_type: "Category", value: data.category },
          { trait_type: "Chain", value: data.chain },
          { trait_type: "Creator", value: walletInfo?.address || "" },
        ],
        external_url: data.enableAffiliate ? data.affiliateUrl : undefined,
        affiliate_url: data.enableAffiliate ? data.affiliateUrl : undefined,
        commission_rate: data.enableAffiliate ? data.affiliateCommission : undefined,
      };

      // Upload metadata to IPFS
      toast({
        title: "Uploading metadata",
        description: "Creating NFT metadata...",
      });
      
      const metadataUrl = await pinataService.uploadMetadata(metadata);

      // Mint NFT on blockchain
      toast({
        title: "Minting NFT",
        description: "Please confirm the transaction in your wallet...",
      });

      const txHash = await web3Service.mintNFT(
        walletInfo?.address || "",
        metadataUrl,
        data.price,
        data.royalty
      );

      // Save to database (would make API call here)
      const nftData = {
        ...data,
        image: imageUrl,
        metadataUri: metadataUrl,
        txHash,
      };

      toast({
        title: "NFT Created Successfully!",
        description: `Your NFT "${data.name}" has been minted and is now available on the marketplace.`,
      });

      if (onSuccess) {
        onSuccess(nftData);
      }

      // Reset form
      form.reset();
      setSelectedFile(null);
      setPreview("");

    } catch (error: any) {
      console.error("Failed to create NFT:", error);
      toast({
        title: "Failed to create NFT",
        description: error.message || "An unexpected error occurred",
        variant: "destructive",
      });
    } finally {
      setMinting(false);
    }
  };

  return (
    <div className="grid lg:grid-cols-2 gap-12">
      {/* Form */}
      <div className="space-y-6">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* File Upload */}
            <Card className="bg-surface-blue/30 border-gray-700">
              <CardHeader>
                <CardTitle className="text-cyan-400">Upload Digital Asset</CardTitle>
              </CardHeader>
              <CardContent>
                <div 
                  className="border-2 border-dashed border-cyan-400/30 rounded-xl p-8 text-center hover:border-cyan-400/60 transition-colors duration-300 cursor-pointer"
                  onClick={() => document.getElementById('file-input')?.click()}
                >
                  <input
                    id="file-input"
                    type="file"
                    accept="image/*,video/*"
                    onChange={handleFileSelect}
                    className="hidden"
                  />
                  
                  {preview ? (
                    <div className="space-y-4">
                      <img 
                        src={preview} 
                        alt="Preview" 
                        className="max-h-32 mx-auto rounded-lg"
                      />
                      <p className="text-green-400 flex items-center justify-center">
                        <CheckCircle className="h-4 w-4 mr-2" />
                        File selected: {selectedFile?.name}
                      </p>
                    </div>
                  ) : (
                    <>
                      <Upload className="h-12 w-12 text-cyan-400 mx-auto mb-4" />
                      <p className="text-gray-300 mb-2">
                        Drag & drop your file here, or <span className="text-cyan-400">browse</span>
                      </p>
                      <p className="text-sm text-gray-400">
                        PNG, JPG, GIF, MP4 (Max 100MB)
                      </p>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* NFT Details */}
            <Card className="bg-surface-blue/30 border-gray-700">
              <CardHeader>
                <CardTitle className="text-cyan-400">NFT Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-300">Name *</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Enter NFT name" 
                          className="bg-surface-dark border-gray-600 focus:border-cyan-400"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-300">Description</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Describe your digital business utility..."
                          className="bg-surface-dark border-gray-600 focus:border-cyan-400"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="category"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-gray-300">Category</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="bg-surface-dark border-gray-600">
                              <SelectValue placeholder="Select category" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="business-tools">Business Tools</SelectItem>
                            <SelectItem value="analytics">Analytics</SelectItem>
                            <SelectItem value="marketing">Marketing</SelectItem>
                            <SelectItem value="automation">Automation</SelectItem>
                            <SelectItem value="security">Security</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="chain"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-gray-300">Blockchain</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="bg-surface-dark border-gray-600">
                              <SelectValue placeholder="Select blockchain" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="ethereum">Ethereum</SelectItem>
                            <SelectItem value="polygon">Polygon</SelectItem>
                            <SelectItem value="bsc">BSC</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Pricing & Affiliate */}
            <Card className="bg-surface-blue/30 border-gray-700">
              <CardHeader>
                <CardTitle className="text-cyan-400">Pricing & Affiliate</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="price"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-gray-300">Price (ETH)</FormLabel>
                        <FormControl>
                          <Input 
                            type="number"
                            step="0.001"
                            placeholder="0.00"
                            className="bg-surface-dark border-gray-600 focus:border-cyan-400"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="royalty"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-gray-300">Royalty (%)</FormLabel>
                        <FormControl>
                          <Input 
                            type="number"
                            min="0"
                            max="10"
                            placeholder="2.5"
                            className="bg-surface-dark border-gray-600 focus:border-cyan-400"
                            {...field}
                            onChange={(e) => field.onChange(parseFloat(e.target.value))}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="border-t border-gray-700 pt-4">
                  <FormField
                    control={form.control}
                    name="enableAffiliate"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border border-gray-700 p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base text-gray-300">
                            Enable Affiliate Program
                          </FormLabel>
                          <FormDescription className="text-gray-400">
                            Allow others to earn commissions by promoting your NFT
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  {watchEnableAffiliate && (
                    <div className="mt-4 space-y-4 p-4 bg-cyan-400/5 rounded-lg border border-cyan-400/20">
                      <FormField
                        control={form.control}
                        name="affiliateCommission"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-300">Commission Rate (%)</FormLabel>
                            <FormControl>
                              <Input 
                                type="number"
                                min="1"
                                max="50"
                                placeholder="15"
                                className="bg-surface-dark border-gray-600 focus:border-cyan-400"
                                {...field}
                                onChange={(e) => field.onChange(parseInt(e.target.value))}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="affiliateUrl"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-300">Affiliate URL</FormLabel>
                            <FormControl>
                              <Input 
                                type="url"
                                placeholder="https://your-business-utility.com"
                                className="bg-surface-dark border-gray-600 focus:border-cyan-400"
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Gas Estimation */}
            <Card className="bg-gradient-to-r from-cyan-400/10 to-pink-500/10 border-cyan-400/30">
              <CardContent className="p-6">
                <div className="flex justify-between items-center">
                  <div>
                    <h4 className="font-bold text-cyan-400">Estimated Gas Fee</h4>
                    <p className="text-sm text-gray-400">Current network: {form.watch("chain")}</p>
                  </div>
                  <div className="text-right">
                    <div className="text-xl font-bold text-pink-400">{gasEstimate} ETH</div>
                    <div className="text-sm text-gray-400">~${(parseFloat(gasEstimate) * 1800).toFixed(2)}</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Submit Button */}
            <CyberButton
              type="submit"
              variant="cyber-primary"
              className="w-full py-4 text-lg"
              disabled={minting || uploading || !isConnected}
              glowEffect
            >
              {minting ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Minting NFT...
                </>
              ) : uploading ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Uploading...
                </>
              ) : (
                <>
                  <Image className="mr-2 h-5 w-5" />
                  Create NFT
                </>
              )}
            </CyberButton>

            {!isConnected && (
              <p className="text-center text-red-400 text-sm">
                Please connect your wallet to create an NFT
              </p>
            )}
          </form>
        </Form>
      </div>

      {/* Preview */}
      <div className="space-y-6">
        <Card className="bg-surface-blue/30 border-gray-700">
          <CardHeader>
            <CardTitle className="text-cyan-400">Preview</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="bg-surface-dark rounded-xl overflow-hidden">
              <div className="w-full h-64 bg-gradient-to-br from-cyan-400/20 to-pink-500/20 flex items-center justify-center">
                {preview ? (
                  <img src={preview} alt="Preview" className="w-full h-full object-cover" />
                ) : (
                  <Image className="h-16 w-16 text-gray-600" />
                )}
              </div>
              
              <div className="p-6">
                <h4 className="text-xl font-bold text-cyan-400 mb-2">
                  {form.watch("name") || "Your NFT Name"}
                </h4>
                <p className="text-gray-400 mb-4">
                  {form.watch("description") || "Your description will appear here..."}
                </p>
                
                <div className="flex justify-between items-center">
                  <div>
                    <div className="text-2xl font-bold text-pink-400">
                      {form.watch("price") ? `${form.watch("price")} ETH` : "-- ETH"}
                    </div>
                    <div className="text-sm text-gray-400">Price</div>
                  </div>
                  <CyberButton variant="cyber-primary">
                    Buy Now
                  </CyberButton>
                </div>

                {form.watch("enableAffiliate") && (
                  <div className="mt-4 p-3 bg-gradient-to-r from-cyan-400/10 to-green-400/10 border border-cyan-400/30 rounded-lg">
                    <div className="text-sm text-gray-300">
                      <Badge className="bg-gradient-to-r from-cyan-400 to-green-400 text-black mr-2">
                        Affiliate
                      </Badge>
                      Earn {form.watch("affiliateCommission") || 15}% commission
                    </div>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Minting Steps */}
        <Card className="bg-surface-blue/30 border-gray-700">
          <CardHeader>
            <CardTitle className="text-cyan-400">Minting Process</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { step: 1, text: "Upload your digital asset to IPFS", active: uploading },
                { step: 2, text: "Create metadata and smart contract", active: false },
                { step: 3, text: "Sign transaction and pay gas fees", active: minting },
                { step: 4, text: "NFT minted and listed on marketplace", active: false },
              ].map(({ step, text, active }) => (
                <div key={step} className="flex items-center space-x-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${
                    active 
                      ? "bg-cyan-400 text-black" 
                      : step === 1 
                        ? "bg-cyan-400 text-black" 
                        : "bg-surface-blue/50 border-2 border-gray-600 text-gray-600"
                  }`}>
                    {active ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      step
                    )}
                  </div>
                  <span className={`${active ? "text-cyan-400" : "text-gray-400"}`}>
                    {text}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
