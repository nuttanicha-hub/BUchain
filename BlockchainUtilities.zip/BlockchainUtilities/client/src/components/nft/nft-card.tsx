import { Card, CardContent } from "@/components/ui/card";
import { CyberButton } from "@/components/ui/cyber-button";
import { Badge } from "@/components/ui/badge";
import { Heart, ExternalLink } from "lucide-react";
import { NFT } from "@shared/schema";
import { useState } from "react";

interface NFTCardProps {
  nft: NFT & {
    creator?: { username: string };
    owner?: { username: string };
  };
  onBuy?: (nft: NFT) => void;
  onFavorite?: (nftId: number) => void;
  isFavorited?: boolean;
}

export function NFTCard({ nft, onBuy, onFavorite, isFavorited = false }: NFTCardProps) {
  const [imageLoaded, setImageLoaded] = useState(false);

  const handleBuy = () => {
    if (onBuy) onBuy(nft);
  };

  const handleFavorite = () => {
    if (onFavorite) onFavorite(nft.id);
  };

  const formatPrice = (price: string | null) => {
    if (!price) return "Not for sale";
    return `${parseFloat(price).toFixed(3)} ETH`;
  };

  const getChainColor = (chain: string) => {
    switch (chain.toLowerCase()) {
      case "ethereum": return "bg-blue-500";
      case "polygon": return "bg-purple-500";
      case "bsc": return "bg-yellow-500";
      default: return "bg-gray-500";
    }
  };

  return (
    <Card className="bg-surface-blue/30 border-gray-700 rounded-xl overflow-hidden nft-card group">
      <div className="relative">
        {!imageLoaded && (
          <div className="w-full h-48 bg-gray-800 animate-pulse flex items-center justify-center">
            <div className="text-gray-600">Loading...</div>
          </div>
        )}
        
        <img
          src={nft.image}
          alt={nft.name}
          className={`w-full h-48 object-cover transition-opacity duration-300 ${
            imageLoaded ? "opacity-100" : "opacity-0"
          }`}
          onLoad={() => setImageLoaded(true)}
          onError={() => setImageLoaded(true)}
        />
        
        <div className="absolute top-3 left-3 flex gap-2">
          <Badge className={`${getChainColor(nft.chain)} text-white text-xs`}>
            {nft.chain.toUpperCase()}
          </Badge>
          {nft.isAffiliate && (
            <Badge className="bg-gradient-to-r from-cyan-400 to-green-400 text-black text-xs">
              Affiliate
            </Badge>
          )}
        </div>

        <div className="absolute top-3 right-3">
          <button
            onClick={handleFavorite}
            className={`p-2 rounded-full backdrop-blur-sm transition-all duration-300 ${
              isFavorited 
                ? "bg-red-500/80 text-white" 
                : "bg-black/50 text-gray-300 hover:text-red-400"
            }`}
          >
            <Heart className="h-4 w-4" fill={isFavorited ? "currentColor" : "none"} />
          </button>
        </div>
      </div>

      <CardContent className="p-4">
        <div className="space-y-3">
          <div>
            <h3 className="font-bold text-cyan-400 text-lg truncate">{nft.name}</h3>
            <p className="text-sm text-gray-400">
              by {nft.creator?.username || "Unknown"}
            </p>
          </div>

          {nft.description && (
            <p className="text-sm text-gray-300 line-clamp-2">{nft.description}</p>
          )}

          <div className="flex items-center justify-between">
            <div>
              <div className="text-lg font-bold text-pink-400">
                {formatPrice(nft.price)}
              </div>
              {nft.price && (
                <div className="text-xs text-gray-400">
                  ~${(parseFloat(nft.price) * 1800).toFixed(0)} USD
                </div>
              )}
            </div>

            <div className="flex space-x-2">
              {nft.isListed && nft.price && (
                <CyberButton
                  size="sm"
                  variant="cyber-primary"
                  onClick={handleBuy}
                >
                  Buy Now
                </CyberButton>
              )}
              
              {nft.affiliateUrl && (
                <button
                  onClick={() => window.open(nft.affiliateUrl, '_blank')}
                  className="p-2 border border-cyan-400 text-cyan-400 rounded-lg hover:bg-cyan-400 hover:text-black transition-all duration-300"
                >
                  <ExternalLink className="h-4 w-4" />
                </button>
              )}
            </div>
          </div>

          {nft.isAffiliate && nft.affiliateCommission && (
            <div className="bg-gradient-to-r from-cyan-400/10 to-green-400/10 border border-cyan-400/30 rounded-lg p-2">
              <div className="text-xs text-gray-300">
                Earn <span className="text-green-400 font-bold">
                  {nft.affiliateCommission}%
                </span> commission on referrals
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
