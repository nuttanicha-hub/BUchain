import { useState } from "react";
import { Link, useLocation } from "wouter";
import { WalletConnect } from "@/components/wallet/wallet-connect";
import { WalletModal } from "@/components/wallet/wallet-modal";
import { GlitchText } from "@/components/ui/glitch-text";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu";
import { 
  Search, 
  Bell, 
  Menu, 
  X, 
  Box,
  Gavel,
  Plus,
  Percent,
  BarChart3
} from "lucide-react";
import { useWeb3Store } from "@/store/web3Store";

export function Header() {
  const [location] = useLocation();
  const [isWalletModalOpen, setIsWalletModalOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const { isConnected } = useWeb3Store();

  const navigationItems = [
    { href: "/marketplace", label: "Marketplace" },
    { href: "/create", label: "Create" },
    { href: "/auctions", label: "Auctions" },
    { href: "/affiliate", label: "Affiliate NFTs" },
  ];

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      // Navigate to marketplace with search query
      window.location.href = `/marketplace?search=${encodeURIComponent(searchQuery)}`;
    }
  };

  return (
    <>
      <header className="fixed top-0 left-0 right-0 z-50 bg-surface-dark/90 backdrop-blur-lg border-b border-cyan-400/20">
        <nav className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <Link href="/" className="flex items-center space-x-3 group">
              <div className="w-10 h-10 bg-gradient-to-br from-cyan-400 to-pink-500 rounded-lg flex items-center justify-center group-hover:shadow-cyber transition-all duration-300">
                <Box className="h-6 w-6 text-white" />
              </div>
              <GlitchText 
                text="BUChain" 
                className="text-2xl font-cyber text-cyan-400"
                animate={true}
              />
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-6">
              {navigationItems.map((item) => (
                <Link key={item.href} href={item.href} className={`hover:text-cyan-400 transition-colors duration-300 font-medium ${
                  location === item.href ? "text-cyan-400" : "text-gray-300"
                }`}>
                  {item.label}
                </Link>
              ))}
            </div>

            {/* Search Bar */}
            <div className="hidden lg:flex items-center flex-1 max-w-md mx-8">
              <form onSubmit={handleSearch} className="relative w-full">
                <Input
                  type="text"
                  placeholder="Search NFTs, collections, users..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-surface-blue/50 border border-cyan-400/30 rounded-lg pl-10 pr-4 py-2 focus:border-cyan-400 focus:shadow-cyber transition-all duration-300"
                />
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-cyan-400/70" />
              </form>
            </div>

            {/* Right Actions */}
            <div className="flex items-center space-x-4">
              {/* Notifications */}
              {isConnected && (
                <Button 
                  variant="ghost" 
                  size="sm"
                  className="relative p-2 hover:bg-surface-blue/50 rounded-lg transition-colors duration-300"
                >
                  <Bell className="h-5 w-5 text-gray-300" />
                  <Badge className="absolute -top-1 -right-1 w-5 h-5 p-0 flex items-center justify-center bg-pink-500 text-white text-xs">
                    3
                  </Badge>
                </Button>
              )}

              {/* Dashboard Link */}
              {isConnected && (
                <Link href="/dashboard">
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className={`hidden sm:flex items-center space-x-2 hover:bg-surface-blue/50 transition-colors duration-300 ${
                      location === "/dashboard" ? "text-cyan-400" : "text-gray-300"
                    }`}
                  >
                    <BarChart3 className="h-4 w-4" />
                    <span>Dashboard</span>
                  </Button>
                </Link>
              )}

              {/* Wallet Connect */}
              <WalletConnect />

              {/* Mobile Menu Toggle */}
              <Button
                variant="ghost"
                size="sm"
                className="md:hidden p-2"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              >
                {isMobileMenuOpen ? (
                  <X className="h-5 w-5" />
                ) : (
                  <Menu className="h-5 w-5" />
                )}
              </Button>
            </div>
          </div>

          {/* Mobile Menu */}
          {isMobileMenuOpen && (
            <div className="md:hidden mt-4 pt-4 border-t border-gray-700">
              {/* Mobile Search */}
              <form onSubmit={handleSearch} className="mb-4">
                <div className="relative">
                  <Input
                    type="text"
                    placeholder="Search NFTs..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-surface-blue/50 border border-cyan-400/30 rounded-lg pl-10 pr-4 py-2"
                  />
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-cyan-400/70" />
                </div>
              </form>

              {/* Mobile Navigation */}
              <div className="space-y-2">
                {navigationItems.map((item) => (
                  <Link 
                    key={item.href} 
                    href={item.href}
                    className={`block px-3 py-2 rounded-lg transition-colors duration-300 ${
                      location === item.href
                        ? "bg-cyan-400/20 text-cyan-400"
                        : "text-gray-300 hover:bg-surface-blue/50"
                    }`}
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    {item.label}
                  </Link>
                ))}
                
                {isConnected && (
                  <Link 
                    href="/dashboard"
                    className={`block px-3 py-2 rounded-lg transition-colors duration-300 ${
                      location === "/dashboard"
                        ? "bg-cyan-400/20 text-cyan-400"
                        : "text-gray-300 hover:bg-surface-blue/50"
                    }`}
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    Dashboard
                  </Link>
                )}
              </div>
            </div>
          )}
        </nav>
      </header>

      <WalletModal 
        isOpen={isWalletModalOpen} 
        onClose={() => setIsWalletModalOpen(false)} 
      />
    </>
  );
}
