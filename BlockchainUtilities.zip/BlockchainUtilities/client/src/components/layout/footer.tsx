import { Link } from "wouter";
import { GlitchText } from "@/components/ui/glitch-text";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Box, 
  Twitter, 
  Github, 
  MessageCircle,
  Send,
  ExternalLink
} from "lucide-react";

export function Footer() {
  const currentYear = new Date().getFullYear();

  const footerLinks = {
    marketplace: [
      { label: "Explore NFTs", href: "/marketplace" },
      { label: "Live Auctions", href: "/auctions" },
      { label: "Collections", href: "/marketplace?view=collections" },
      { label: "Trending", href: "/marketplace?sort=trending" },
      { label: "New Drops", href: "/marketplace?sort=recent" },
    ],
    create: [
      { label: "Mint NFT", href: "/create" },
      { label: "Create Collection", href: "/create/collection" },
      { label: "Affiliate Program", href: "/affiliate" },
      { label: "Documentation", href: "/docs" },
      { label: "API", href: "/api-docs" },
    ],
    support: [
      { label: "Help Center", href: "/help" },
      { label: "Contact Us", href: "/contact" },
      { label: "Bug Reports", href: "/bugs" },
      { label: "Feature Requests", href: "/features" },
      { label: "Status Page", href: "/status" },
    ],
    legal: [
      { label: "Privacy Policy", href: "/privacy" },
      { label: "Terms of Service", href: "/terms" },
      { label: "Cookie Policy", href: "/cookies" },
    ],
  };

  const socialLinks = [
    {
      icon: Twitter,
      href: "https://twitter.com/buchain",
      label: "Twitter",
      color: "hover:text-blue-400",
    },
    {
      icon: Github,
      href: "https://github.com/buchain",
      label: "GitHub",
      color: "hover:text-gray-300",
    },
    {
      icon: MessageCircle,
      href: "https://discord.gg/buchain",
      label: "Discord",
      color: "hover:text-indigo-400",
    },
    {
      icon: Send,
      href: "https://t.me/buchain",
      label: "Telegram",
      color: "hover:text-blue-500",
    },
  ];

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle newsletter subscription
    console.log("Newsletter subscription");
  };

  return (
    <footer className="bg-surface-dark border-t border-cyan-400/20">
      <div className="container mx-auto px-4 py-16">
        {/* Main Footer Content */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Brand Section */}
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-cyan-400 to-pink-500 rounded-lg flex items-center justify-center">
                <Box className="h-6 w-6 text-white" />
              </div>
              <GlitchText 
                text="BUChain" 
                className="text-2xl font-cyber text-cyan-400"
              />
            </div>
            <p className="text-gray-400 text-sm leading-relaxed">
              The ultimate Web3 NFT marketplace for trading digital business utilities 
              across multiple blockchains. Empowering creators and businesses with 
              cutting-edge technology.
            </p>
            
            {/* Social Links */}
            <div className="flex space-x-4">
              {socialLinks.map((social) => {
                const Icon = social.icon;
                return (
                  <a
                    key={social.label}
                    href={social.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`text-cyan-400 ${social.color} transition-colors duration-300`}
                    aria-label={social.label}
                  >
                    <Icon className="h-5 w-5" />
                  </a>
                );
              })}
            </div>
          </div>

          {/* Marketplace Links */}
          <div>
            <h4 className="text-lg font-bold text-cyan-400 mb-4">Marketplace</h4>
            <ul className="space-y-2">
              {footerLinks.marketplace.map((link) => (
                <li key={link.href}>
                  <Link href={link.href} className="text-gray-400 hover:text-cyan-400 transition-colors duration-300 text-sm">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Create Links */}
          <div>
            <h4 className="text-lg font-bold text-cyan-400 mb-4">Create</h4>
            <ul className="space-y-2">
              {footerLinks.create.map((link) => (
                <li key={link.href}>
                  <Link href={link.href} className="text-gray-400 hover:text-cyan-400 transition-colors duration-300 text-sm">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Support Links */}
          <div>
            <h4 className="text-lg font-bold text-cyan-400 mb-4">Support</h4>
            <ul className="space-y-2">
              {footerLinks.support.map((link) => (
                <li key={link.href}>
                  <Link href={link.href} className="text-gray-400 hover:text-cyan-400 transition-colors duration-300 text-sm">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Newsletter Section */}
        <div className="bg-gradient-to-r from-surface-blue/30 to-surface-dark/30 rounded-xl p-6 mb-8">
          <div className="grid md:grid-cols-2 gap-6 items-center">
            <div>
              <h3 className="text-xl font-bold text-cyan-400 mb-2">Stay Updated</h3>
              <p className="text-gray-400">
                Get the latest updates on new NFT drops, auctions, and platform features. 
                Join our community of digital innovators.
              </p>
            </div>
            <form onSubmit={handleNewsletterSubmit} className="flex space-x-2">
              <Input
                type="email"
                placeholder="Enter your email"
                className="flex-1 bg-surface-dark border-gray-600 focus:border-cyan-400"
                required
              />
              <Button
                type="submit"
                className="bg-gradient-to-r from-cyan-400 to-pink-500 text-black font-bold hover:shadow-cyber transition-all duration-300"
              >
                Subscribe
              </Button>
            </form>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-700 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm mb-4 md:mb-0">
              © {currentYear} BUChain. All rights reserved. Built for the future of digital business utilities.
            </p>
            
            <div className="flex flex-wrap gap-6">
              {footerLinks.legal.map((link) => (
                <Link key={link.href} href={link.href} className="text-gray-400 hover:text-cyan-400 transition-colors duration-300 text-sm">
                  {link.label}
                </Link>
              ))}
            </div>
          </div>

          {/* Additional Info */}
          <div className="mt-6 pt-6 border-t border-gray-700/50 text-center">
            <p className="text-gray-500 text-xs mb-2">
              BUChain is a decentralized platform. Always verify smart contracts and do your own research.
            </p>
            <div className="flex justify-center items-center space-x-4 text-xs text-gray-500">
              <span>Powered by Ethereum, Polygon & BSC</span>
              <span>•</span>
              <a 
                href="https://etherscan.io" 
                target="_blank" 
                rel="noopener noreferrer"
                className="hover:text-cyan-400 transition-colors duration-300 flex items-center"
              >
                View on Etherscan <ExternalLink className="ml-1 h-3 w-3" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
