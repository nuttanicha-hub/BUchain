import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { CyberButton } from "@/components/ui/cyber-button";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { X, Filter } from "lucide-react";

interface FilterState {
  categories: string[];
  priceRange: [number, number];
  chains: string[];
  status: string;
  hasAffiliate: boolean;
  sortBy: string;
}

interface MarketplaceFiltersProps {
  filters: FilterState;
  onFiltersChange: (filters: FilterState) => void;
  onClearFilters: () => void;
}

export function MarketplaceFilters({ 
  filters, 
  onFiltersChange, 
  onClearFilters 
}: MarketplaceFiltersProps) {
  const [showMobileFilters, setShowMobileFilters] = useState(false);
  const [tempPriceRange, setTempPriceRange] = useState(filters.priceRange);

  const categories = [
    { id: "business-tools", label: "Business Tools", count: 1234 },
    { id: "analytics", label: "Analytics", count: 856 },
    { id: "marketing", label: "Marketing", count: 642 },
    { id: "automation", label: "Automation", count: 378 },
    { id: "security", label: "Security", count: 291 },
  ];

  const chains = [
    { id: "ethereum", label: "Ethereum", count: 2847 },
    { id: "polygon", label: "Polygon", count: 1523 },
    { id: "bsc", label: "BSC", count: 892 },
  ];

  const statusOptions = [
    { id: "buy-now", label: "Buy Now" },
    { id: "auction", label: "On Auction" },
    { id: "offers", label: "Has Offers" },
    { id: "all", label: "All" },
  ];

  const handleCategoryChange = (categoryId: string, checked: boolean) => {
    const newCategories = checked
      ? [...filters.categories, categoryId]
      : filters.categories.filter(c => c !== categoryId);
    
    onFiltersChange({ ...filters, categories: newCategories });
  };

  const handleChainChange = (chainId: string, checked: boolean) => {
    const newChains = checked
      ? [...filters.chains, chainId]
      : filters.chains.filter(c => c !== chainId);
    
    onFiltersChange({ ...filters, chains: newChains });
  };

  const handlePriceRangeChange = () => {
    onFiltersChange({ ...filters, priceRange: tempPriceRange });
  };

  const getActiveFilterCount = () => {
    let count = 0;
    if (filters.categories.length > 0) count++;
    if (filters.chains.length > 0) count++;
    if (filters.status !== "all") count++;
    if (filters.hasAffiliate) count++;
    if (filters.priceRange[0] > 0 || filters.priceRange[1] < 100) count++;
    return count;
  };

  const FilterContent = () => (
    <div className="space-y-6">
      {/* Category Filter */}
      <Card className="bg-surface-blue/30 border-gray-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg text-cyan-400">Category</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {categories.map((category) => (
            <div key={category.id} className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id={category.id}
                  checked={filters.categories.includes(category.id)}
                  onCheckedChange={(checked) => 
                    handleCategoryChange(category.id, checked as boolean)
                  }
                  className="border-gray-600 data-[state=checked]:bg-cyan-400 data-[state=checked]:border-cyan-400"
                />
                <Label htmlFor={category.id} className="text-sm text-gray-300 cursor-pointer">
                  {category.label}
                </Label>
              </div>
              <Badge variant="secondary" className="text-xs bg-gray-700 text-gray-400">
                {category.count.toLocaleString()}
              </Badge>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Price Range Filter */}
      <Card className="bg-surface-blue/30 border-gray-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg text-cyan-400">Price Range (ETH)</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="px-2">
            <Slider
              value={tempPriceRange}
              onValueChange={setTempPriceRange}
              max={100}
              step={0.1}
              className="w-full"
            />
          </div>
          <div className="flex space-x-2">
            <Input
              type="number"
              placeholder="Min"
              value={tempPriceRange[0]}
              onChange={(e) => setTempPriceRange([parseFloat(e.target.value) || 0, tempPriceRange[1]])}
              className="flex-1 bg-surface-dark border-gray-600 text-sm"
            />
            <Input
              type="number"
              placeholder="Max"
              value={tempPriceRange[1]}
              onChange={(e) => setTempPriceRange([tempPriceRange[0], parseFloat(e.target.value) || 100])}
              className="flex-1 bg-surface-dark border-gray-600 text-sm"
            />
          </div>
          <CyberButton 
            onClick={handlePriceRangeChange}
            variant="cyber-primary"
            className="w-full"
            size="sm"
          >
            Apply
          </CyberButton>
        </CardContent>
      </Card>

      {/* Blockchain Filter */}
      <Card className="bg-surface-blue/30 border-gray-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg text-cyan-400">Blockchain</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {chains.map((chain) => (
            <div key={chain.id} className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id={chain.id}
                  checked={filters.chains.includes(chain.id)}
                  onCheckedChange={(checked) => 
                    handleChainChange(chain.id, checked as boolean)
                  }
                  className="border-gray-600 data-[state=checked]:bg-cyan-400 data-[state=checked]:border-cyan-400"
                />
                <Label htmlFor={chain.id} className="text-sm text-gray-300 cursor-pointer">
                  {chain.label}
                </Label>
              </div>
              <Badge variant="secondary" className="text-xs bg-gray-700 text-gray-400">
                {chain.count.toLocaleString()}
              </Badge>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Status Filter */}
      <Card className="bg-surface-blue/30 border-gray-700">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg text-cyan-400">Status</CardTitle>
        </CardHeader>
        <CardContent>
          <RadioGroup
            value={filters.status}
            onValueChange={(value) => onFiltersChange({ ...filters, status: value })}
            className="space-y-2"
          >
            {statusOptions.map((option) => (
              <div key={option.id} className="flex items-center space-x-2">
                <RadioGroupItem
                  value={option.id}
                  id={option.id}
                  className="border-gray-600 text-cyan-400"
                />
                <Label htmlFor={option.id} className="text-sm text-gray-300 cursor-pointer">
                  {option.label}
                </Label>
              </div>
            ))}
          </RadioGroup>
        </CardContent>
      </Card>

      {/* Affiliate Filter */}
      <Card className="bg-surface-blue/30 border-gray-700">
        <CardContent className="pt-6">
          <div className="flex items-center space-x-2">
            <Checkbox
              id="affiliate"
              checked={filters.hasAffiliate}
              onCheckedChange={(checked) => 
                onFiltersChange({ ...filters, hasAffiliate: checked as boolean })
              }
              className="border-gray-600 data-[state=checked]:bg-cyan-400 data-[state=checked]:border-cyan-400"
            />
            <Label htmlFor="affiliate" className="text-sm text-gray-300 cursor-pointer">
              Has Affiliate Program
            </Label>
          </div>
        </CardContent>
      </Card>

      {/* Clear Filters */}
      {getActiveFilterCount() > 0 && (
        <Button
          onClick={onClearFilters}
          variant="outline"
          className="w-full border-red-500 text-red-500 hover:bg-red-500 hover:text-white"
        >
          Clear All Filters ({getActiveFilterCount()})
        </Button>
      )}
    </div>
  );

  return (
    <>
      {/* Mobile Filter Toggle */}
      <div className="lg:hidden mb-4">
        <Button
          onClick={() => setShowMobileFilters(!showMobileFilters)}
          variant="outline"
          className="w-full border-cyan-400 text-cyan-400"
        >
          <Filter className="h-4 w-4 mr-2" />
          Filters {getActiveFilterCount() > 0 && `(${getActiveFilterCount()})`}
        </Button>
      </div>

      {/* Desktop Filters */}
      <div className="hidden lg:block">
        <FilterContent />
      </div>

      {/* Mobile Filters Modal */}
      {showMobileFilters && (
        <div className="lg:hidden fixed inset-0 z-50 bg-black/80 flex items-end">
          <div className="w-full bg-surface-dark border-t border-cyan-400/30 rounded-t-2xl max-h-[80vh] overflow-y-auto">
            <div className="p-4 border-b border-gray-700 flex justify-between items-center">
              <h3 className="text-lg font-bold text-cyan-400">Filters</h3>
              <Button
                onClick={() => setShowMobileFilters(false)}
                variant="ghost"
                size="sm"
                className="text-gray-400"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
            <div className="p-4">
              <FilterContent />
            </div>
          </div>
        </div>
      )}
    </>
  );
}
