import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { NFTCard } from "@/components/nft/nft-card";
import { NFTCardSkeleton } from "@/components/ui/loading-skeleton";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Grid, List, ChevronLeft, ChevronRight } from "lucide-react";
import { NFT } from "@shared/schema";

interface MarketplaceGridProps {
  filters: {
    categories: string[];
    priceRange: [number, number];
    chains: string[];
    status: string;
    hasAffiliate: boolean;
    sortBy: string;
    search?: string;
  };
  onFiltersChange: (filters: any) => void;
}

interface MarketplaceResponse {
  nfts: (NFT & {
    creator?: { username: string };
    owner?: { username: string };
  })[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

export function MarketplaceGrid({ filters, onFiltersChange }: MarketplaceGridProps) {
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [currentPage, setCurrentPage] = useState(1);
  const [favoritedNFTs, setFavoritedNFTs] = useState<Set<number>>(new Set());
  const limit = 12;

  // Fetch NFTs based on filters and pagination
  const { data, isLoading, error } = useQuery<MarketplaceResponse>({
    queryKey: ['/api/nfts/marketplace', filters, currentPage, limit],
    queryFn: async () => {
      const params = new URLSearchParams({
        page: currentPage.toString(),
        limit: limit.toString(),
        sortBy: filters.sortBy,
        status: filters.status,
        hasAffiliate: filters.hasAffiliate.toString(),
        ...(filters.categories.length > 0 && { categories: filters.categories.join(',') }),
        ...(filters.chains.length > 0 && { chains: filters.chains.join(',') }),
        ...(filters.priceRange[0] > 0 && { minPrice: filters.priceRange[0].toString() }),
        ...(filters.priceRange[1] < 100 && { maxPrice: filters.priceRange[1].toString() }),
        ...(filters.search && { search: filters.search }),
      });

      const response = await fetch(`/api/nfts/marketplace?${params}`);
      if (!response.ok) {
        throw new Error('Failed to fetch NFTs');
      }
      return response.json();
    },
  });

  // Reset page when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [filters]);

  const handleSortChange = (sortBy: string) => {
    onFiltersChange({ ...filters, sortBy });
  };

  const handleBuyNFT = async (nft: NFT) => {
    try {
      // Implement purchase logic here
      console.log('Purchasing NFT:', nft.id);
    } catch (error) {
      console.error('Failed to purchase NFT:', error);
    }
  };

  const handleFavoriteNFT = (nftId: number) => {
    setFavoritedNFTs(prev => {
      const newSet = new Set(prev);
      if (newSet.has(nftId)) {
        newSet.delete(nftId);
      } else {
        newSet.add(nftId);
      }
      return newSet;
    });
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const renderPagination = () => {
    if (!data || data.totalPages <= 1) return null;

    const pages = [];
    const maxVisiblePages = 5;
    const startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
    const endPage = Math.min(data.totalPages, startPage + maxVisiblePages - 1);

    for (let i = startPage; i <= endPage; i++) {
      pages.push(i);
    }

    return (
      <div className="flex justify-center items-center space-x-2 mt-12">
        <Button
          onClick={() => handlePageChange(currentPage - 1)}
          disabled={currentPage === 1}
          variant="outline"
          size="sm"
          className="border-gray-600 text-gray-400 hover:border-cyan-400 hover:text-cyan-400"
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>

        {startPage > 1 && (
          <>
            <Button
              onClick={() => handlePageChange(1)}
              variant="outline"
              size="sm"
              className="border-gray-600 text-gray-400 hover:border-cyan-400 hover:text-cyan-400"
            >
              1
            </Button>
            {startPage > 2 && <span className="text-gray-400">...</span>}
          </>
        )}

        {pages.map(page => (
          <Button
            key={page}
            onClick={() => handlePageChange(page)}
            variant={currentPage === page ? "default" : "outline"}
            size="sm"
            className={
              currentPage === page
                ? "bg-cyan-400 text-black hover:bg-cyan-500"
                : "border-gray-600 text-gray-400 hover:border-cyan-400 hover:text-cyan-400"
            }
          >
            {page}
          </Button>
        ))}

        {endPage < data.totalPages && (
          <>
            {endPage < data.totalPages - 1 && <span className="text-gray-400">...</span>}
            <Button
              onClick={() => handlePageChange(data.totalPages)}
              variant="outline"
              size="sm"
              className="border-gray-600 text-gray-400 hover:border-cyan-400 hover:text-cyan-400"
            >
              {data.totalPages}
            </Button>
          </>
        )}

        <Button
          onClick={() => handlePageChange(currentPage + 1)}
          disabled={currentPage === data.totalPages}
          variant="outline"
          size="sm"
          className="border-gray-600 text-gray-400 hover:border-cyan-400 hover:text-cyan-400"
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
    );
  };

  if (error) {
    return (
      <div className="text-center py-12">
        <div className="text-red-400 text-lg mb-4">Failed to load NFTs</div>
        <p className="text-gray-400">Please try again later</p>
      </div>
    );
  }

  return (
    <div className="flex-1">
      {/* Header with controls */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div className="flex items-center space-x-4">
          <div className="text-gray-400">
            {isLoading ? (
              "Loading..."
            ) : data ? (
              `Found ${data.total.toLocaleString()} items`
            ) : (
              "No items found"
            )}
          </div>
          
          {/* Active filters */}
          <div className="flex flex-wrap gap-2">
            {filters.categories.map(category => (
              <Badge
                key={category}
                variant="secondary"
                className="bg-cyan-400/20 text-cyan-400 border border-cyan-400/30"
              >
                {category}
              </Badge>
            ))}
            {filters.chains.map(chain => (
              <Badge
                key={chain}
                variant="secondary"
                className="bg-purple-400/20 text-purple-400 border border-purple-400/30"
              >
                {chain}
              </Badge>
            ))}
            {filters.hasAffiliate && (
              <Badge
                variant="secondary"
                className="bg-green-400/20 text-green-400 border border-green-400/30"
              >
                Affiliate
              </Badge>
            )}
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          {/* View mode toggle */}
          <div className="flex items-center space-x-2">
            <Button
              onClick={() => setViewMode("grid")}
              variant={viewMode === "grid" ? "default" : "outline"}
              size="sm"
              className={viewMode === "grid" ? "bg-cyan-400 text-black" : "border-gray-600 text-gray-400"}
            >
              <Grid className="h-4 w-4" />
            </Button>
            <Button
              onClick={() => setViewMode("list")}
              variant={viewMode === "list" ? "default" : "outline"}
              size="sm"
              className={viewMode === "list" ? "bg-cyan-400 text-black" : "border-gray-600 text-gray-400"}
            >
              <List className="h-4 w-4" />
            </Button>
          </div>
          
          {/* Sort dropdown */}
          <Select value={filters.sortBy} onValueChange={handleSortChange}>
            <SelectTrigger className="w-48 bg-surface-dark border-gray-600">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="price_asc">Price: Low to High</SelectItem>
              <SelectItem value="price_desc">Price: High to Low</SelectItem>
              <SelectItem value="created_desc">Recently Listed</SelectItem>
              <SelectItem value="popular">Most Popular</SelectItem>
              <SelectItem value="name_asc">Name: A to Z</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* NFT Grid/List */}
      {isLoading ? (
        <div className={`grid gap-6 ${
          viewMode === "grid" 
            ? "md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4" 
            : "grid-cols-1"
        }`}>
          {Array.from({ length: limit }).map((_, index) => (
            <NFTCardSkeleton key={index} />
          ))}
        </div>
      ) : data && data.nfts.length > 0 ? (
        <>
          <div className={`grid gap-6 mb-12 ${
            viewMode === "grid" 
              ? "md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4" 
              : "grid-cols-1"
          }`}>
            {data.nfts.map((nft) => (
              <NFTCard
                key={nft.id}
                nft={nft}
                onBuy={handleBuyNFT}
                onFavorite={handleFavoriteNFT}
                isFavorited={favoritedNFTs.has(nft.id)}
              />
            ))}
          </div>
          
          {renderPagination()}
        </>
      ) : (
        <div className="text-center py-12">
          <div className="text-gray-400 text-lg mb-4">No NFTs found</div>
          <p className="text-gray-500">Try adjusting your filters or search terms</p>
        </div>
      )}
    </div>
  );
}
