import { Card, CardContent } from "@/components/ui/card";
import { CyberButton } from "@/components/ui/cyber-button";
import { Badge } from "@/components/ui/badge";
import { Percent, TrendingUp, ExternalLink, Share2, Copy } from "lucide-react";
import { NFT, AffiliateTracking } from "@shared/schema";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

interface AffiliateNFTCardProps {
  nft: NFT & {
    creator?: { username: string };
    affiliateTracking?: AffiliateTracking;
  };
  onPurchase?: (nft: NFT) => void;
  onShare?: (nft: NFT) => void;
  userAddress?: string;
}

export function AffiliateNFTCard({ 
  nft, 
  onPurchase, 
  onShare,
  userAddress 
}: AffiliateNFTCardProps) {
  const [imageLoaded, setImageLoaded] = useState(false);
  const { toast } = useToast();

  const handlePurchase = () => {
    if (onPurchase) onPurchase(nft);
  };

  const handleShare = () => {
    if (onShare) onShare(nft);
  };

  const handleCopyAffiliateLink = async () => {
    if (!nft.affiliateUrl) return;
    
    const affiliateLink = `${nft.affiliateUrl}?ref=${userAddress}&nft=${nft.id}`;
    
    try {
      await navigator.clipboard.writeText(affiliateLink);
      toast({
        title: "Affiliate link copied!",
        description: "Share this link to earn commissions on referrals",
      });
    } catch (error) {
      toast({
        title: "Failed to copy link",
        description: "Please try again",
        variant: "destructive",
      });
    }
  };

  const formatPrice = (price: string | null) => {
    if (!price) return "Not for sale";
    return `${parseFloat(price).toFixed(3)} ETH`;
  };

  const formatEarnings = (earnings: string | null) => {
    if (!earnings) return "0";
    return parseFloat(earnings).toFixed(4);
  };

  const commissionAmount = nft.price && nft.affiliateCommission 
    ? (parseFloat(nft.price) * parseFloat(nft.affiliateCommission) / 100).toFixed(4)
    : "0";

  return (
    <Card className="bg-gradient-to-br from-surface-dark via-surface-blue to-surface-dark border-cyan-400/30 rounded-xl overflow-hidden nft-card relative cyber-border">
      {/* Commission Badge */}
      <div className="absolute top-4 left-4 z-10">
        <Badge className="bg-gradient-to-r from-cyan-400 to-green-400 text-black text-xs font-bold flex items-center">
          <Percent className="h-3 w-3 mr-1" />
          {nft.affiliateCommission}% COMMISSION
        </Badge>
      </div>

      <div className="relative">
        {!imageLoaded && (
          <div className="w-full h-48 bg-gray-800 animate-pulse flex items-center justify-center">
            <div className="text-gray-600">Loading...</div>
          </div>
        )}
        
        <img
          src={nft.image}
          alt={nft.name}
          className={`w-full h-48 object-cover transition-opacity duration-300 ${
            imageLoaded ? "opacity-100" : "opacity-0"
          }`}
          onLoad={() => setImageLoaded(true)}
          onError={() => setImageLoaded(true)}
        />
      </div>

      <CardContent className="p-6">
        <div className="space-y-4">
          <div>
            <h3 className="text-xl font-bold text-cyan-400 mb-2">{nft.name}</h3>
            <p className="text-gray-400 text-sm mb-3">
              {nft.description || "Digital business utility with affiliate rewards"}
            </p>
            <p className="text-xs text-gray-500">
              by {nft.creator?.username || "Unknown"}
            </p>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-surface-dark/50 rounded-lg p-3">
              <div className="text-sm text-gray-400">Price</div>
              <div className="text-lg font-bold text-pink-400">{formatPrice(nft.price)}</div>
            </div>
            
            <div className="bg-surface-dark/50 rounded-lg p-3">
              <div className="text-sm text-gray-400">Commission</div>
              <div className="text-lg font-bold text-green-400">{nft.affiliateCommission}%</div>
            </div>
            
            <div className="bg-surface-dark/50 rounded-lg p-3">
              <div className="text-sm text-gray-400">Per Sale</div>
              <div className="text-lg font-bold text-cyan-400">{commissionAmount} ETH</div>
            </div>
            
            <div className="bg-surface-dark/50 rounded-lg p-3">
              <div className="text-sm text-gray-400">Referrals</div>
              <div className="text-lg font-bold text-purple-400">
                {nft.affiliateTracking?.conversionCount || 0}
              </div>
            </div>
          </div>

          {/* Total Earnings */}
          {nft.affiliateTracking && (
            <div className="bg-gradient-to-r from-green-400/10 to-cyan-400/10 border border-green-400/30 rounded-lg p-3">
              <div className="flex justify-between items-center">
                <div>
                  <div className="text-sm text-gray-400">Total Earnings</div>
                  <div className="text-xl font-bold text-green-400">
                    {formatEarnings(nft.affiliateTracking.totalEarnings)} ETH
                  </div>
                </div>
                <TrendingUp className="h-6 w-6 text-green-400" />
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="space-y-3">
            <div className="flex space-x-2">
              <CyberButton
                onClick={handlePurchase}
                variant="cyber-primary"
                className="flex-1"
                disabled={!nft.isListed || !nft.price}
              >
                Buy & Earn
              </CyberButton>
              
              {nft.affiliateUrl && (
                <CyberButton
                  onClick={() => window.open(nft.affiliateUrl, '_blank')}
                  variant="cyber-outline"
                  size="sm"
                  className="px-3"
                >
                  <ExternalLink className="h-4 w-4" />
                </CyberButton>
              )}
            </div>

            {/* Share and Copy Affiliate Link */}
            <div className="flex space-x-2">
              <CyberButton
                onClick={handleShare}
                variant="cyber-secondary"
                className="flex-1"
                size="sm"
              >
                <Share2 className="h-4 w-4 mr-2" />
                Share
              </CyberButton>
              
              <CyberButton
                onClick={handleCopyAffiliateLink}
                variant="cyber-ghost"
                className="flex-1"
                size="sm"
              >
                <Copy className="h-4 w-4 mr-2" />
                Copy Link
              </CyberButton>
            </div>
          </div>

          {/* Earnings Projection */}
          <div className="text-center text-xs text-gray-400 border-t border-gray-700 pt-3">
            {nft.price && nft.affiliateCommission && (
              <div>
                <div className="mb-1">Potential Earnings per Referral:</div>
                <div className="text-cyan-400 font-mono">
                  {commissionAmount} ETH (~${(parseFloat(commissionAmount) * 1800).toFixed(2)})
                </div>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
