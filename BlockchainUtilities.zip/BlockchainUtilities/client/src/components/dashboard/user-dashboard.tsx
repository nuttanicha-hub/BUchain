import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { DashboardStats } from "./dashboard-stats";
import { NFTCard } from "@/components/nft/nft-card";
import { NFTCardSkeleton } from "@/components/ui/loading-skeleton";
import { 
  BarChart3, 
  Images, 
  Plus, 
  Gavel, 
  Percent, 
  Settings,
  TrendingUp,
  ShoppingBag,
  ArrowRight,
  Calendar,
  Clock
} from "lucide-react";
import { useWeb3Store } from "@/store/web3Store";
import { NFT, Transaction } from "@shared/schema";

interface DashboardData {
  stats: {
    ownedNFTs: number;
    createdNFTs: number;
    totalEarnings: string;
    activeBids: number;
    affiliateEarnings: string;
    affiliateReferrals: number;
    monthlyChange: {
      earnings: number;
      nfts: number;
      bids: number;
    };
  };
  recentNFTs: (NFT & {
    creator?: { username: string };
    purchasePrice?: string;
    currentValue?: string;
  })[];
  recentActivity: (Transaction & {
    nft?: { name: string };
    fromUser?: { username: string };
    toUser?: { username: string };
  })[];
}

export function UserDashboard() {
  const [activeTab, setActiveTab] = useState("overview");
  const { walletInfo } = useWeb3Store();

  const { data, isLoading, error } = useQuery<DashboardData>({
    queryKey: ['/api/dashboard', walletInfo?.address],
    enabled: !!walletInfo?.address,
  });

  const tabs = [
    { id: "overview", label: "Overview", icon: BarChart3 },
    { id: "my-nfts", label: "My NFTs", icon: Images },
    { id: "created", label: "Created", icon: Plus },
    { id: "auctions", label: "Auctions", icon: Gavel },
    { id: "affiliate", label: "Affiliate Earnings", icon: Percent },
    { id: "settings", label: "Settings", icon: Settings },
  ];

  const formatAddress = (address: string) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  const formatTimeAgo = (date: string) => {
    const now = new Date();
    const past = new Date(date);
    const diffInHours = Math.floor((now.getTime() - past.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return "Just now";
    if (diffInHours < 24) return `${diffInHours}h ago`;
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}d ago`;
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case "buy": return ShoppingBag;
      case "bid": return Gavel;
      case "mint": return Plus;
      case "transfer": return ArrowRight;
      default: return TrendingUp;
    }
  };

  const getActivityColor = (type: string) => {
    switch (type) {
      case "buy": return "text-pink-400";
      case "bid": return "text-purple-400";
      case "mint": return "text-green-400";
      case "transfer": return "text-blue-400";
      default: return "text-gray-400";
    }
  };

  if (!walletInfo) {
    return (
      <div className="container mx-auto px-4 py-16">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-400 mb-4">
            Connect your wallet to view dashboard
          </h2>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-16">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-red-400 mb-4">
            Failed to load dashboard
          </h2>
          <p className="text-gray-400">Please try again later</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid lg:grid-cols-4 gap-8">
        {/* Sidebar */}
        <div className="lg:col-span-1">
          <Card className="bg-surface-blue/30 border-gray-700 sticky top-24">
            <CardContent className="p-6">
              {/* User Profile */}
              <div className="text-center mb-6">
                <Avatar className="w-20 h-20 mx-auto mb-4">
                  <AvatarFallback className="bg-gradient-to-br from-cyan-400 to-purple-500 text-white text-xl">
                    {walletInfo.address.slice(2, 4).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <h3 className="font-bold text-cyan-400 text-lg">
                  {formatAddress(walletInfo.address)}
                </h3>
                <Badge className="bg-green-400/20 text-green-400 border border-green-400/30 mt-2">
                  Verified
                </Badge>
              </div>

              {/* Navigation */}
              <nav className="space-y-2">
                {tabs.map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`w-full flex items-center space-x-3 p-3 rounded-lg font-semibold transition-colors duration-300 ${
                        activeTab === tab.id
                          ? "bg-cyan-400/20 text-cyan-400"
                          : "hover:bg-surface-blue/50 text-gray-300"
                      }`}
                    >
                      <Icon className="h-5 w-5" />
                      <span>{tab.label}</span>
                    </button>
                  );
                })}
              </nav>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="lg:col-span-3">
          {activeTab === "overview" && (
            <div className="space-y-8">
              {/* Stats */}
              {isLoading ? (
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {Array.from({ length: 4 }).map((_, i) => (
                    <NFTCardSkeleton key={i} />
                  ))}
                </div>
              ) : data ? (
                <DashboardStats stats={data.stats} />
              ) : null}

              {/* Recent Activity */}
              <Card className="bg-surface-blue/30 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-xl text-cyan-400">Recent Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <div className="space-y-4">
                      {Array.from({ length: 3 }).map((_, i) => (
                        <div key={i} className="flex items-center space-x-4 p-4 bg-surface-dark/50 rounded-lg">
                          <div className="w-12 h-12 bg-gray-700 rounded-lg animate-pulse"></div>
                          <div className="flex-1 space-y-2">
                            <div className="h-4 bg-gray-700 rounded animate-pulse"></div>
                            <div className="h-3 bg-gray-700 rounded w-1/2 animate-pulse"></div>
                          </div>
                          <div className="h-6 w-16 bg-gray-700 rounded animate-pulse"></div>
                        </div>
                      ))}
                    </div>
                  ) : data?.recentActivity?.length ? (
                    <div className="space-y-4">
                      {data.recentActivity.slice(0, 5).map((activity) => {
                        const Icon = getActivityIcon(activity.type);
                        const colorClass = getActivityColor(activity.type);
                        
                        return (
                          <div key={activity.id} className="flex items-center space-x-4 p-4 bg-surface-dark/50 rounded-lg hover:bg-surface-dark/70 transition-colors duration-300">
                            <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                              activity.type === "buy" ? "bg-pink-400/20" :
                              activity.type === "bid" ? "bg-purple-400/20" :
                              activity.type === "mint" ? "bg-green-400/20" :
                              "bg-blue-400/20"
                            }`}>
                              <Icon className={`h-6 w-6 ${colorClass}`} />
                            </div>
                            <div className="flex-1">
                              <p className="text-white font-medium">
                                {activity.type === "buy" && `Purchased ${activity.nft?.name || "NFT"}`}
                                {activity.type === "bid" && `Placed bid on ${activity.nft?.name || "NFT"}`}
                                {activity.type === "mint" && `Minted ${activity.nft?.name || "NFT"}`}
                                {activity.type === "transfer" && `Transferred ${activity.nft?.name || "NFT"}`}
                              </p>
                              <p className="text-sm text-gray-400 flex items-center">
                                <Clock className="h-3 w-3 mr-1" />
                                {formatTimeAgo(activity.createdAt)}
                              </p>
                            </div>
                            <div className="text-right">
                              <div className={`font-bold ${
                                activity.amount && parseFloat(activity.amount) > 0 
                                  ? "text-green-400" 
                                  : "text-pink-400"
                              }`}>
                                {activity.amount ? `${parseFloat(activity.amount).toFixed(3)} ETH` : "-"}
                              </div>
                              <div className="text-xs text-gray-400 capitalize">
                                {activity.type}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-gray-400">
                      No recent activity
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Recent NFTs */}
              <Card className="bg-surface-blue/30 border-gray-700">
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle className="text-xl text-cyan-400">My NFTs</CardTitle>
                  <Button
                    onClick={() => setActiveTab("my-nfts")}
                    variant="outline"
                    size="sm"
                    className="border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-black"
                  >
                    View All <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <div className="grid md:grid-cols-3 gap-6">
                      {Array.from({ length: 3 }).map((_, i) => (
                        <NFTCardSkeleton key={i} />
                      ))}
                    </div>
                  ) : data?.recentNFTs?.length ? (
                    <div className="grid md:grid-cols-3 gap-6">
                      {data.recentNFTs.slice(0, 3).map((nft) => (
                        <div key={nft.id} className="bg-surface-dark/50 rounded-lg overflow-hidden">
                          <img 
                            src={nft.image} 
                            alt={nft.name}
                            className="w-full h-32 object-cover"
                          />
                          <div className="p-3">
                            <h4 className="font-bold text-cyan-400 text-sm truncate">{nft.name}</h4>
                            <div className="text-xs text-gray-400 mt-1">
                              {nft.purchasePrice && (
                                <div>Bought: {parseFloat(nft.purchasePrice).toFixed(3)} ETH</div>
                              )}
                              {nft.currentValue && (
                                <div className={
                                  parseFloat(nft.currentValue) > parseFloat(nft.purchasePrice || "0")
                                    ? "text-green-400"
                                    : "text-pink-400"
                                }>
                                  Current: {parseFloat(nft.currentValue).toFixed(3)} ETH
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-gray-400">
                      No NFTs found
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          )}

          {/* Other tabs would render different content */}
          {activeTab !== "overview" && (
            <div className="text-center py-16">
              <h3 className="text-xl font-bold text-gray-400 mb-4">
                {tabs.find(t => t.id === activeTab)?.label}
              </h3>
              <p className="text-gray-500">
                This section is under development
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
