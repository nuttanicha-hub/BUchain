import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  TrendingUp, 
  TrendingDown, 
  Images, 
  Plus, 
  Coins, 
  Gavel,
  Percent,
  Users
} from "lucide-react";

interface DashboardStatsProps {
  stats: {
    ownedNFTs: number;
    createdNFTs: number;
    totalEarnings: string;
    activeBids: number;
    affiliateEarnings: string;
    affiliateReferrals: number;
    monthlyChange: {
      earnings: number;
      nfts: number;
      bids: number;
    };
  };
}

export function DashboardStats({ stats }: DashboardStatsProps) {
  const formatChange = (change: number) => {
    const isPositive = change >= 0;
    return {
      value: Math.abs(change),
      isPositive,
      color: isPositive ? "text-green-400" : "text-red-400",
      icon: isPositive ? TrendingUp : TrendingDown,
    };
  };

  const earningsChange = formatChange(stats.monthlyChange.earnings);
  const nftsChange = formatChange(stats.monthlyChange.nfts);
  const bidsChange = formatChange(stats.monthlyChange.bids);

  return (
    <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
      {/* Owned NFTs */}
      <Card className="bg-gradient-to-br from-cyan-400/20 to-cyan-400/5 border-cyan-400/30">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold text-cyan-400">
                {stats.ownedNFTs.toLocaleString()}
              </div>
              <div className="text-sm text-gray-400">Owned NFTs</div>
              <div className="flex items-center mt-2">
                <nftsChange.icon className={`h-3 w-3 mr-1 ${nftsChange.color}`} />
                <span className={`text-xs ${nftsChange.color}`}>
                  {nftsChange.value}% this month
                </span>
              </div>
            </div>
            <div className="p-3 bg-cyan-400/20 rounded-lg">
              <Images className="h-6 w-6 text-cyan-400" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Created NFTs */}
      <Card className="bg-gradient-to-br from-pink-500/20 to-pink-500/5 border-pink-500/30">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold text-pink-500">
                {stats.createdNFTs.toLocaleString()}
              </div>
              <div className="text-sm text-gray-400">Created NFTs</div>
              <div className="flex items-center mt-2">
                <Plus className="h-3 w-3 mr-1 text-pink-500" />
                <span className="text-xs text-pink-500">
                  Recently minted
                </span>
              </div>
            </div>
            <div className="p-3 bg-pink-500/20 rounded-lg">
              <Plus className="h-6 w-6 text-pink-500" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Total Earnings */}
      <Card className="bg-gradient-to-br from-green-400/20 to-green-400/5 border-green-400/30">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold text-green-400">
                {parseFloat(stats.totalEarnings).toFixed(3)} ETH
              </div>
              <div className="text-sm text-gray-400">Total Earnings</div>
              <div className="flex items-center mt-2">
                <earningsChange.icon className={`h-3 w-3 mr-1 ${earningsChange.color}`} />
                <span className={`text-xs ${earningsChange.color}`}>
                  {earningsChange.value}% this month
                </span>
              </div>
            </div>
            <div className="p-3 bg-green-400/20 rounded-lg">
              <Coins className="h-6 w-6 text-green-400" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Active Bids */}
      <Card className="bg-gradient-to-br from-purple-500/20 to-purple-500/5 border-purple-500/30">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold text-purple-500">
                {stats.activeBids.toLocaleString()}
              </div>
              <div className="text-sm text-gray-400">Active Bids</div>
              <div className="flex items-center mt-2">
                <bidsChange.icon className={`h-3 w-3 mr-1 ${bidsChange.color}`} />
                <span className={`text-xs ${bidsChange.color}`}>
                  {bidsChange.value}% this month
                </span>
              </div>
            </div>
            <div className="p-3 bg-purple-500/20 rounded-lg">
              <Gavel className="h-6 w-6 text-purple-500" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Affiliate Earnings */}
      <Card className="bg-gradient-to-br from-yellow-400/20 to-yellow-400/5 border-yellow-400/30 lg:col-span-2">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold text-yellow-400">
                {parseFloat(stats.affiliateEarnings).toFixed(4)} ETH
              </div>
              <div className="text-sm text-gray-400">Affiliate Earnings</div>
              <div className="flex items-center mt-2 space-x-4">
                <div className="flex items-center">
                  <Users className="h-3 w-3 mr-1 text-cyan-400" />
                  <span className="text-xs text-cyan-400">
                    {stats.affiliateReferrals} referrals
                  </span>
                </div>
                <Badge className="bg-gradient-to-r from-cyan-400 to-green-400 text-black text-xs">
                  Active Program
                </Badge>
              </div>
            </div>
            <div className="p-3 bg-yellow-400/20 rounded-lg">
              <Percent className="h-6 w-6 text-yellow-400" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Portfolio Value */}
      <Card className="bg-gradient-to-br from-blue-400/20 to-blue-400/5 border-blue-400/30 lg:col-span-2">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-2xl font-bold text-blue-400">
                {((parseFloat(stats.totalEarnings) + parseFloat(stats.affiliateEarnings)) * 1800).toLocaleString('en-US', {
                  style: 'currency',
                  currency: 'USD',
                  minimumFractionDigits: 0,
                  maximumFractionDigits: 0,
                })}
              </div>
              <div className="text-sm text-gray-400">Portfolio Value (USD)</div>
              <div className="flex items-center mt-2">
                <TrendingUp className="h-3 w-3 mr-1 text-green-400" />
                <span className="text-xs text-green-400">
                  Based on current ETH price
                </span>
              </div>
            </div>
            <div className="p-3 bg-blue-400/20 rounded-lg">
              <TrendingUp className="h-6 w-6 text-blue-400" />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
