interface PinataConfig {
  apiKey: string;
  apiSecret: string;
  jwt: string;
}

interface PinataResponse {
  IpfsHash: string;
  PinSize: number;
  Timestamp: string;
  isDuplicate?: boolean;
}

interface NFTMetadata {
  name: string;
  description: string;
  image: string;
  attributes: Array<{
    trait_type: string;
    value: string | number;
  }>;
  external_url?: string;
  affiliate_url?: string;
  commission_rate?: number;
}

class PinataService {
  private config: PinataConfig;

  constructor() {
    this.config = {
      apiKey: import.meta.env.VITE_PINATA_API_KEY || '',
      apiSecret: import.meta.env.VITE_PINATA_API_SECRET || '',
      jwt: import.meta.env.VITE_PINATA_JWT || '',
    };
  }

  async uploadFile(file: File): Promise<string> {
    const formData = new FormData();
    formData.append('file', file);

    const metadata = JSON.stringify({
      name: file.name,
      keyvalues: {
        uploadedBy: 'BUChain',
        timestamp: Date.now().toString(),
      }
    });
    formData.append('pinataMetadata', metadata);

    const options = JSON.stringify({
      cidVersion: 0,
    });
    formData.append('pinataOptions', options);

    try {
      const response = await fetch('https://api.pinata.cloud/pinning/pinFileToIPFS', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.config.jwt}`,
        },
        body: formData,
      });

      if (!response.ok) {
        throw new Error(`Pinata upload failed: ${response.statusText}`);
      }

      const result: PinataResponse = await response.json();
      return `https://gateway.pinata.cloud/ipfs/${result.IpfsHash}`;
    } catch (error) {
      console.error('Failed to upload file to Pinata:', error);
      throw error;
    }
  }

  async uploadMetadata(metadata: NFTMetadata): Promise<string> {
    try {
      const response = await fetch('https://api.pinata.cloud/pinning/pinJSONToIPFS', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.config.jwt}`,
        },
        body: JSON.stringify({
          pinataContent: metadata,
          pinataMetadata: {
            name: `${metadata.name}_metadata`,
            keyvalues: {
              type: 'nft-metadata',
              uploadedBy: 'BUChain',
              timestamp: Date.now().toString(),
            }
          },
          pinataOptions: {
            cidVersion: 0,
          }
        }),
      });

      if (!response.ok) {
        throw new Error(`Pinata metadata upload failed: ${response.statusText}`);
      }

      const result: PinataResponse = await response.json();
      return `https://gateway.pinata.cloud/ipfs/${result.IpfsHash}`;
    } catch (error) {
      console.error('Failed to upload metadata to Pinata:', error);
      throw error;
    }
  }

  async unpinFile(ipfsHash: string): Promise<void> {
    try {
      const response = await fetch(`https://api.pinata.cloud/pinning/unpin/${ipfsHash}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${this.config.jwt}`,
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to unpin file: ${response.statusText}`);
      }
    } catch (error) {
      console.error('Failed to unpin file from Pinata:', error);
      throw error;
    }
  }

  async testAuthentication(): Promise<boolean> {
    try {
      const response = await fetch('https://api.pinata.cloud/data/testAuthentication', {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${this.config.jwt}`,
        },
      });

      return response.ok;
    } catch (error) {
      console.error('Pinata authentication test failed:', error);
      return false;
    }
  }

  getGatewayUrl(ipfsHash: string): string {
    return `https://gateway.pinata.cloud/ipfs/${ipfsHash}`;
  }
}

export const pinataService = new PinataService();
export type { NFTMetadata, PinataResponse };
