import { io, Socket } from 'socket.io-client';

interface AuctionUpdate {
  auctionId: number;
  currentBid: string;
  bidderId: number;
  timeLeft: number;
  bidCount: number;
}

interface NotificationData {
  type: 'bid' | 'outbid' | 'auction_end' | 'purchase' | 'affiliate_earn';
  title: string;
  message: string;
  data?: any;
}

class SocketService {
  private socket: Socket | null = null;
  private listeners: Map<string, Function[]> = new Map();

  connect(): void {
    if (this.socket?.connected) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    this.socket = io(wsUrl, {
      transports: ['websocket'],
      autoConnect: true,
    });

    this.socket.on('connect', () => {
      console.log('Connected to BUChain socket server');
    });

    this.socket.on('disconnect', () => {
      console.log('Disconnected from socket server');
    });

    this.socket.on('auction_update', (data: AuctionUpdate) => {
      this.emit('auction_update', data);
    });

    this.socket.on('notification', (data: NotificationData) => {
      this.emit('notification', data);
    });

    this.socket.on('bid_placed', (data: any) => {
      this.emit('bid_placed', data);
    });

    this.socket.on('auction_ended', (data: any) => {
      this.emit('auction_ended', data);
    });
  }

  disconnect(): void {
    if (this.socket) {
      this.socket.disconnect();
      this.socket = null;
    }
    this.listeners.clear();
  }

  on(event: string, callback: Function): void {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, []);
    }
    this.listeners.get(event)!.push(callback);
  }

  off(event: string, callback?: Function): void {
    if (!callback) {
      this.listeners.delete(event);
      return;
    }

    const eventListeners = this.listeners.get(event);
    if (eventListeners) {
      const index = eventListeners.indexOf(callback);
      if (index > -1) {
        eventListeners.splice(index, 1);
      }
    }
  }

  emit(event: string, data?: any): void {
    const eventListeners = this.listeners.get(event);
    if (eventListeners) {
      eventListeners.forEach(callback => callback(data));
    }
  }

  joinAuction(auctionId: number): void {
    if (this.socket?.connected) {
      this.socket.emit('join_auction', { auctionId });
    }
  }

  leaveAuction(auctionId: number): void {
    if (this.socket?.connected) {
      this.socket.emit('leave_auction', { auctionId });
    }
  }

  placeBid(auctionId: number, amount: string, userId: number): void {
    if (this.socket?.connected) {
      this.socket.emit('place_bid', { auctionId, amount, userId });
    }
  }

  subscribeToUser(userId: number): void {
    if (this.socket?.connected) {
      this.socket.emit('subscribe_user', { userId });
    }
  }

  unsubscribeFromUser(userId: number): void {
    if (this.socket?.connected) {
      this.socket.emit('unsubscribe_user', { userId });
    }
  }

  isConnected(): boolean {
    return this.socket?.connected || false;
  }
}

export const socketService = new SocketService();
export type { AuctionUpdate, NotificationData };
