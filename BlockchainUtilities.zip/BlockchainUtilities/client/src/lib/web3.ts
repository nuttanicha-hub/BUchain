import { ethers } from 'ethers';

export interface WalletInfo {
  address: string;
  balance: string;
  chainId: number;
  network: string;
}

export interface NFTMetadata {
  name: string;
  description: string;
  image: string;
  attributes: Array<{
    trait_type: string;
    value: string | number;
  }>;
  affiliate_url?: string;
  commission_rate?: number;
}

class Web3Service {
  private provider: ethers.BrowserProvider | null = null;
  private signer: ethers.JsonRpcSigner | null = null;

  async connectWallet(): Promise<WalletInfo | null> {
    if (!window.ethereum) {
      throw new Error('MetaMask is not installed');
    }

    try {
      const provider = new ethers.BrowserProvider(window.ethereum);
      const accounts = await provider.send('eth_requestAccounts', []);
      
      if (accounts.length === 0) {
        throw new Error('No accounts found');
      }

      const signer = await provider.getSigner();
      const address = await signer.getAddress();
      const balance = await provider.getBalance(address);
      const network = await provider.getNetwork();

      this.provider = provider;
      this.signer = signer;

      return {
        address,
        balance: ethers.formatEther(balance),
        chainId: Number(network.chainId),
        network: network.name,
      };
    } catch (error) {
      console.error('Failed to connect wallet:', error);
      throw error;
    }
  }

  async disconnectWallet(): Promise<void> {
    this.provider = null;
    this.signer = null;
  }

  async switchNetwork(chainId: number): Promise<void> {
    if (!window.ethereum) {
      throw new Error('MetaMask is not installed');
    }

    try {
      await window.ethereum.request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId: `0x${chainId.toString(16)}` }],
      });
    } catch (error: any) {
      if (error.code === 4902) {
        // Network not added, add it
        await this.addNetwork(chainId);
      } else {
        throw error;
      }
    }
  }

  private async addNetwork(chainId: number): Promise<void> {
    const networks: Record<number, any> = {
      137: {
        chainId: '0x89',
        chainName: 'Polygon Mainnet',
        nativeCurrency: {
          name: 'MATIC',
          symbol: 'MATIC',
          decimals: 18,
        },
        rpcUrls: ['https://polygon-rpc.com/'],
        blockExplorerUrls: ['https://polygonscan.com/'],
      },
      56: {
        chainId: '0x38',
        chainName: 'Binance Smart Chain',
        nativeCurrency: {
          name: 'BNB',
          symbol: 'BNB',
          decimals: 18,
        },
        rpcUrls: ['https://bsc-dataseed.binance.org/'],
        blockExplorerUrls: ['https://bscscan.com/'],
      },
    };

    const networkConfig = networks[chainId];
    if (!networkConfig) {
      throw new Error('Unsupported network');
    }

    await window.ethereum.request({
      method: 'wallet_addEthereumChain',
      params: [networkConfig],
    });
  }

  async mintNFT(
    to: string,
    metadataUri: string,
    price: string,
    royalty: number
  ): Promise<string> {
    if (!this.signer) {
      throw new Error('Wallet not connected');
    }

    // This would integrate with your actual NFT contract
    // For now, we'll simulate the transaction
    const tx = await this.signer.sendTransaction({
      to: '0x0000000000000000000000000000000000000000', // Replace with actual contract address
      value: ethers.parseEther('0.01'), // Minting fee
      data: '0x', // Contract call data
    });

    return tx.hash;
  }

  async placeBid(auctionId: string, amount: string): Promise<string> {
    if (!this.signer) {
      throw new Error('Wallet not connected');
    }

    const tx = await this.signer.sendTransaction({
      to: '0x0000000000000000000000000000000000000000', // Replace with actual auction contract
      value: ethers.parseEther(amount),
      data: '0x', // Contract call data for placing bid
    });

    return tx.hash;
  }

  async estimateGas(
    to: string,
    value: string,
    data: string = '0x'
  ): Promise<string> {
    if (!this.provider) {
      throw new Error('Provider not available');
    }

    const gasEstimate = await this.provider.estimateGas({
      to,
      value: ethers.parseEther(value),
      data,
    });

    const gasPrice = await this.provider.getFeeData();
    const totalCost = gasEstimate * (gasPrice.gasPrice || BigInt(0));

    return ethers.formatEther(totalCost);
  }

  getProvider(): ethers.BrowserProvider | null {
    return this.provider;
  }

  getSigner(): ethers.JsonRpcSigner | null {
    return this.signer;
  }
}

// Extend window object for TypeScript
declare global {
  interface Window {
    ethereum?: any;
  }
}

export const web3Service = new Web3Service();
