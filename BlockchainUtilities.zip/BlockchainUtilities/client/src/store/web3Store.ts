import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { web3Service, WalletInfo } from '@/lib/web3';

interface Web3State {
  isConnected: boolean;
  isConnecting: boolean;
  walletInfo: WalletInfo | null;
  error: string | null;
  
  // Actions
  connectWallet: () => Promise<void>;
  disconnectWallet: () => void;
  switchNetwork: (chainId: number) => Promise<void>;
  clearError: () => void;
  setError: (error: string) => void;
}

export const useWeb3Store = create<Web3State>()(
  persist(
    (set, get) => ({
      isConnected: false,
      isConnecting: false,
      walletInfo: null,
      error: null,

      connectWallet: async () => {
        set({ isConnecting: true, error: null });
        
        try {
          const walletInfo = await web3Service.connectWallet();
          if (walletInfo) {
            set({
              isConnected: true,
              walletInfo,
              isConnecting: false,
            });
          }
        } catch (error: any) {
          set({
            error: error.message || 'Failed to connect wallet',
            isConnecting: false,
          });
        }
      },

      disconnectWallet: () => {
        web3Service.disconnectWallet();
        set({
          isConnected: false,
          walletInfo: null,
          error: null,
        });
      },

      switchNetwork: async (chainId: number) => {
        try {
          await web3Service.switchNetwork(chainId);
          // Re-fetch wallet info after network switch
          const walletInfo = await web3Service.connectWallet();
          if (walletInfo) {
            set({ walletInfo });
          }
        } catch (error: any) {
          set({ error: error.message || 'Failed to switch network' });
        }
      },

      clearError: () => {
        set({ error: null });
      },

      setError: (error: string) => {
        set({ error });
      },
    }),
    {
      name: 'web3-storage',
      partialize: (state) => ({
        isConnected: state.isConnected,
        walletInfo: state.walletInfo,
      }),
    }
  )
);
