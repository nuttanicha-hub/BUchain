import { create } from 'zustand';
import { socketService, AuctionUpdate } from '@/lib/socket';

interface AuctionState {
  activeAuctions: Map<number, AuctionUpdate>;
  isConnected: boolean;
  
  // Actions
  initializeSocket: () => void;
  joinAuction: (auctionId: number) => void;
  leaveAuction: (auctionId: number) => void;
  updateAuction: (auctionData: AuctionUpdate) => void;
  placeBid: (auctionId: number, amount: string, userId: number) => void;
  getAuction: (auctionId: number) => AuctionUpdate | undefined;
  disconnect: () => void;
}

export const useAuctionStore = create<AuctionState>((set, get) => ({
  activeAuctions: new Map(),
  isConnected: false,

  initializeSocket: () => {
    socketService.connect();
    
    socketService.on('connect', () => {
      set({ isConnected: true });
    });

    socketService.on('disconnect', () => {
      set({ isConnected: false });
    });

    socketService.on('auction_update', (data: AuctionUpdate) => {
      get().updateAuction(data);
    });

    socketService.on('bid_placed', (data: any) => {
      // Handle bid placed event
      console.log('Bid placed:', data);
    });

    socketService.on('auction_ended', (data: any) => {
      // Handle auction ended event
      console.log('Auction ended:', data);
      const auctions = new Map(get().activeAuctions);
      auctions.delete(data.auctionId);
      set({ activeAuctions: auctions });
    });
  },

  joinAuction: (auctionId: number) => {
    socketService.joinAuction(auctionId);
  },

  leaveAuction: (auctionId: number) => {
    socketService.leaveAuction(auctionId);
  },

  updateAuction: (auctionData: AuctionUpdate) => {
    set((state) => {
      const newAuctions = new Map(state.activeAuctions);
      newAuctions.set(auctionData.auctionId, auctionData);
      return { activeAuctions: newAuctions };
    });
  },

  placeBid: (auctionId: number, amount: string, userId: number) => {
    socketService.placeBid(auctionId, amount, userId);
  },

  getAuction: (auctionId: number) => {
    return get().activeAuctions.get(auctionId);
  },

  disconnect: () => {
    socketService.disconnect();
    set({ isConnected: false, activeAuctions: new Map() });
  },
}));
