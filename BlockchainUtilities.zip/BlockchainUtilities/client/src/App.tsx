import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import Marketplace from "@/pages/marketplace";
import Create from "@/pages/create";
import Auctions from "@/pages/auctions";
import Affiliate from "@/pages/affiliate";
import Dashboard from "@/pages/dashboard";

function Router() {
  return (
    <div className="min-h-screen bg-space-dark text-white">
      <Header />
      <main>
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/marketplace" component={Marketplace} />
          <Route path="/create" component={Create} />
          <Route path="/auctions" component={Auctions} />
          <Route path="/affiliate" component={Affiliate} />
          <Route path="/dashboard" component={Dashboard} />
          {/* Fallback to 404 */}
          <Route component={NotFound} />
        </Switch>
      </main>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
