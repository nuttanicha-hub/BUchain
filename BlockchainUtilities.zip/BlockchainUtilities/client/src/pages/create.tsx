import { useState } from "react";
import { Link } from "wouter";
import { CreateNFTForm } from "@/components/nft/create-nft-form";
import { GlitchText } from "@/components/ui/glitch-text";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Image, 
  Zap, 
  Shield, 
  TrendingUp, 
  ArrowRight,
  CheckCircle,
  Wallet,
  Upload,
  Globe
} from "lucide-react";
import { useWeb3Store } from "@/store/web3Store";

export default function Create() {
  const [createdNFT, setCreatedNFT] = useState<any>(null);
  const { isConnected } = useWeb3Store();

  const steps = [
    {
      icon: Upload,
      title: "Upload Asset",
      description: "Upload your digital business utility file",
      detail: "Supported formats: PNG, JPG, GIF, MP4 up to 100MB",
    },
    {
      icon: Image,
      title: "Add Details",
      description: "Provide name, description, and category",
      detail: "Make your NFT discoverable with detailed metadata",
    },
    {
      icon: Globe,
      title: "Choose Blockchain",
      description: "Select Ethereum, Polygon, or BSC",
      detail: "Each blockchain has different fees and benefits",
    },
    {
      icon: Zap,
      title: "Mint & List",
      description: "Create your NFT and list it for sale",
      detail: "Pay gas fees and your NFT will be live instantly",
    },
  ];

  const benefits = [
    {
      icon: Shield,
      title: "Verified & Secure",
      description: "All NFTs are verified on-chain and fully decentralized",
      color: "from-green-400 to-cyan-500",
    },
    {
      icon: TrendingUp,
      title: "Earn Royalties",
      description: "Get paid every time your NFT is resold",
      color: "from-purple-400 to-pink-500",
    },
    {
      icon: Wallet,
      title: "Multi-Chain Support",
      description: "Create on Ethereum, Polygon, or Binance Smart Chain",
      color: "from-blue-400 to-cyan-500",
    },
  ];

  const handleNFTCreated = (nft: any) => {
    setCreatedNFT(nft);
    // Scroll to success section
    document.getElementById('success-section')?.scrollIntoView({ 
      behavior: 'smooth' 
    });
  };

  if (createdNFT) {
    return (
      <div className="min-h-screen bg-space-dark text-white pt-24">
        <div className="container mx-auto px-4 py-16" id="success-section">
          <div className="max-w-2xl mx-auto text-center">
            <div className="w-20 h-20 bg-gradient-to-br from-green-400 to-cyan-500 rounded-full mx-auto mb-6 flex items-center justify-center">
              <CheckCircle className="h-10 w-10 text-white" />
            </div>
            
            <h1 className="text-4xl font-cyber text-green-400 mb-4">
              NFT CREATED SUCCESSFULLY!
            </h1>
            
            <p className="text-xl text-gray-300 mb-8">
              Your NFT "<span className="text-cyan-400 font-bold">{createdNFT.name}</span>" 
              has been minted and is now live on the marketplace.
            </p>

            <Card className="bg-surface-blue/30 border-cyan-400/30 mb-8">
              <CardContent className="p-6">
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-cyan-400">
                      {createdNFT.price} ETH
                    </div>
                    <div className="text-sm text-gray-400">Listed Price</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-pink-500">
                      {createdNFT.royalty}%
                    </div>
                    <div className="text-sm text-gray-400">Royalty</div>
                  </div>
                </div>
                
                {createdNFT.enableAffiliate && (
                  <div className="mt-4 p-3 bg-gradient-to-r from-cyan-400/10 to-green-400/10 border border-cyan-400/30 rounded-lg">
                    <Badge className="bg-gradient-to-r from-cyan-400 to-green-400 text-black mb-2">
                      Affiliate Enabled
                    </Badge>
                    <div className="text-sm text-gray-300">
                      Commission: <span className="text-green-400 font-bold">
                        {createdNFT.affiliateCommission}%
                      </span>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href={`/nft/${createdNFT.id || '1'}`}>
                <button className="bg-gradient-to-r from-cyan-400 to-cyan-500 text-black px-8 py-3 rounded-lg font-bold hover:shadow-cyber transition-all duration-300">
                  View NFT
                </button>
              </Link>
              
              <Link href="/marketplace">
                <button className="border-2 border-cyan-400 text-cyan-400 px-8 py-3 rounded-lg font-bold hover:bg-cyan-400 hover:text-black transition-all duration-300">
                  Browse Marketplace
                </button>
              </Link>
              
              <button 
                onClick={() => setCreatedNFT(null)}
                className="text-gray-400 hover:text-white transition-colors duration-300"
              >
                Create Another NFT
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-space-dark text-white pt-24">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <GlitchText 
            text="CREATE YOUR NFT"
            className="text-4xl lg:text-6xl font-cyber text-cyan-400 mb-4"
          />
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Mint your digital business utility as an NFT and start earning from day one. 
            Join thousands of creators building the future of digital commerce.
          </p>
        </div>

        {!isConnected && (
          <div className="max-w-2xl mx-auto mb-12">
            <Card className="bg-gradient-to-r from-yellow-400/10 to-orange-500/10 border-yellow-400/30">
              <CardContent className="p-6 text-center">
                <Wallet className="h-12 w-12 text-yellow-400 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-yellow-400 mb-2">
                  Connect Your Wallet
                </h3>
                <p className="text-gray-300 mb-4">
                  You need to connect your wallet to create and mint NFTs
                </p>
                <div className="text-sm text-gray-400">
                  Supported wallets: MetaMask, WalletConnect, Coinbase Wallet
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Benefits Section */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {benefits.map((benefit, index) => {
            const Icon = benefit.icon;
            return (
              <Card key={index} className="bg-surface-blue/30 border-gray-700 hover:border-cyan-400/50 transition-all duration-300">
                <CardContent className="p-6 text-center">
                  <div className={`w-16 h-16 mx-auto mb-4 rounded-xl bg-gradient-to-br ${benefit.color} flex items-center justify-center`}>
                    <Icon className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-cyan-400 mb-2">
                    {benefit.title}
                  </h3>
                  <p className="text-gray-400">
                    {benefit.description}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Creation Process */}
        <div className="mb-16">
          <h2 className="text-3xl font-cyber text-cyan-400 text-center mb-8">
            CREATION PROCESS
          </h2>
          
          <div className="grid md:grid-cols-4 gap-8">
            {steps.map((step, index) => {
              const Icon = step.icon;
              return (
                <div key={index} className="text-center">
                  <div className="relative mb-4">
                    <div className="w-16 h-16 mx-auto bg-gradient-to-br from-cyan-400 to-pink-500 rounded-full flex items-center justify-center">
                      <Icon className="h-8 w-8 text-white" />
                    </div>
                    <div className="absolute -top-2 -right-2 w-8 h-8 bg-surface-dark border-2 border-cyan-400 rounded-full flex items-center justify-center text-cyan-400 font-bold text-sm">
                      {index + 1}
                    </div>
                    
                    {index < steps.length - 1 && (
                      <div className="hidden md:block absolute top-8 left-full w-full h-0.5 bg-gradient-to-r from-cyan-400 to-transparent"></div>
                    )}
                  </div>
                  
                  <h3 className="text-lg font-bold text-cyan-400 mb-2">
                    {step.title}
                  </h3>
                  <p className="text-gray-400 text-sm mb-2">
                    {step.description}
                  </p>
                  <p className="text-gray-500 text-xs">
                    {step.detail}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Creation Form */}
        <div className="max-w-7xl mx-auto">
          <CreateNFTForm onSuccess={handleNFTCreated} />
        </div>

        {/* Additional Info */}
        <div className="mt-16">
          <Card className="bg-gradient-to-r from-surface-blue/30 to-surface-dark/30 border-cyan-400/30">
            <CardHeader>
              <CardTitle className="text-2xl font-cyber text-cyan-400 text-center">
                NEED HELP?
              </CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-gray-300 mb-6">
                New to NFTs? Check out our comprehensive guide to get started with creating and selling digital assets.
              </p>
              
              <div className="flex flex-wrap justify-center gap-4">
                <Link href="/docs/getting-started">
                  <button className="flex items-center space-x-2 text-cyan-400 hover:text-white transition-colors duration-300">
                    <span>Getting Started Guide</span>
                    <ArrowRight className="h-4 w-4" />
                  </button>
                </Link>
                
                <Link href="/docs/best-practices">
                  <button className="flex items-center space-x-2 text-cyan-400 hover:text-white transition-colors duration-300">
                    <span>Best Practices</span>
                    <ArrowRight className="h-4 w-4" />
                  </button>
                </Link>
                
                <Link href="/support">
                  <button className="flex items-center space-x-2 text-cyan-400 hover:text-white transition-colors duration-300">
                    <span>Contact Support</span>
                    <ArrowRight className="h-4 w-4" />
                  </button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
