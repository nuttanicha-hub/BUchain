import { useState, useEffect } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { GlitchText } from "@/components/ui/glitch-text";
import { CyberButton } from "@/components/ui/cyber-button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { NFTCard } from "@/components/nft/nft-card";
import { AuctionCard } from "@/components/nft/auction-card";
import { AffiliateNFTCard } from "@/components/affiliate/affiliate-nft-card";
import { NFTCardSkeleton, AuctionCardSkeleton } from "@/components/ui/loading-skeleton";
import { 
  Rocket, 
  Plus, 
  TrendingUp,
  Zap,
  Users,
  ArrowRight,
  Play,
  Star,
  Award
} from "lucide-react";
import { NFT, Auction, Collection } from "@shared/schema";
import { useAuctionStore } from "@/store/auctionStore";

interface HomeData {
  stats: {
    totalNFTs: string;
    totalVolume: string;
    activeUsers: string;
  };
  featuredNFT: NFT & {
    creator?: { username: string };
    currentBid?: string;
    auctionEndTime?: string;
  };
  featuredCollections: (Collection & {
    creator?: { username: string };
  })[];
  liveAuctions: (Auction & {
    nft: NFT & {
      creator?: { username: string };
    };
    highestBidder?: { username: string };
  })[];
  trendingNFTs: (NFT & {
    creator?: { username: string };
  })[];
  affiliateNFTs: (NFT & {
    creator?: { username: string };
  })[];
}

export default function Home() {
  const [animationStage, setAnimationStage] = useState(0);
  const { initializeSocket } = useAuctionStore();

  // Initialize WebSocket connection for real-time updates
  useEffect(() => {
    initializeSocket();
  }, [initializeSocket]);

  // Staggered animations
  useEffect(() => {
    const timeouts = [
      setTimeout(() => setAnimationStage(1), 100),
      setTimeout(() => setAnimationStage(2), 300),
      setTimeout(() => setAnimationStage(3), 500),
    ];

    return () => timeouts.forEach(clearTimeout);
  }, []);

  const { data, isLoading } = useQuery<HomeData>({
    queryKey: ['/api/home'],
  });

  const features = [
    {
      icon: Zap,
      title: "Lightning Fast",
      description: "Instant transactions across multiple blockchains",
      color: "from-yellow-400 to-orange-500",
    },
    {
      icon: Users,
      title: "Community Driven",
      description: "Built by creators, for creators and businesses",
      color: "from-blue-400 to-purple-500",
    },
    {
      icon: Award,
      title: "Verified & Secure",
      description: "All transactions are verified and transparent",
      color: "from-green-400 to-cyan-500",
    },
  ];

  return (
    <div className="min-h-screen bg-space-dark text-white">
      {/* Hero Section */}
      <section className="pt-24 pb-16 relative overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-cyan-400/10 to-pink-500/10"></div>
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-cyan-400/20 rounded-full blur-3xl animate-float"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-pink-500/20 rounded-full blur-3xl animate-float" style={{animationDelay: "1s"}}></div>
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Hero Content */}
            <div className={`space-y-8 ${animationStage >= 1 ? "animate-slide-up" : "opacity-0"}`}>
              <div className="space-y-4">
                <GlitchText 
                  text="DIGITAL BUSINESS UTILITIES"
                  className="text-5xl lg:text-7xl font-cyber text-cyan-400 leading-tight"
                  dataText="DIGITAL BUSINESS UTILITIES"
                />
                <p className="text-xl lg:text-2xl text-gray-300 leading-relaxed">
                  The ultimate Web3 NFT marketplace for trading digital business utilities 
                  across multiple blockchains.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/marketplace">
                  <CyberButton 
                    variant="cyber-primary" 
                    className="text-lg px-8 py-4"
                    glowEffect
                  >
                    <Rocket className="mr-2 h-5 w-5" />
                    Explore Marketplace
                  </CyberButton>
                </Link>
                
                <Link href="/create">
                  <CyberButton 
                    variant="cyber-outline" 
                    className="text-lg px-8 py-4"
                  >
                    <Plus className="mr-2 h-5 w-5" />
                    Create NFT
                  </CyberButton>
                </Link>
              </div>

              {/* Stats */}
              <div className={`grid grid-cols-3 gap-6 pt-8 ${animationStage >= 2 ? "animate-slide-up" : "opacity-0"}`}>
                <div className="text-center">
                  <div className="text-3xl font-bold text-cyan-400">
                    {data?.stats.totalNFTs || "24.7K"}
                  </div>
                  <div className="text-gray-400 text-sm">NFTs Created</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-pink-500">
                    {data?.stats.totalVolume || "₿ 891"}
                  </div>
                  <div className="text-gray-400 text-sm">Total Volume</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-400">
                    {data?.stats.activeUsers || "15.2K"}
                  </div>
                  <div className="text-gray-400 text-sm">Active Users</div>
                </div>
              </div>
            </div>

            {/* Featured NFT */}
            <div className={`${animationStage >= 3 ? "animate-slide-up" : "opacity-0"}`}>
              {isLoading ? (
                <AuctionCardSkeleton />
              ) : data?.featuredNFT ? (
                <Card className="bg-surface-dark/80 border-cyan-400/30 rounded-2xl overflow-hidden cyber-border">
                  <div className="relative">
                    <img 
                      src={data.featuredNFT.image}
                      alt={data.featuredNFT.name}
                      className="w-full h-64 object-cover"
                    />
                    <Badge className="absolute top-4 left-4 bg-gradient-to-r from-cyan-400 to-pink-500 text-black font-bold">
                      Featured
                    </Badge>
                  </div>
                  <CardContent className="p-6">
                    <div className="space-y-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="text-xl font-bold text-cyan-400">
                            {data.featuredNFT.name}
                          </h3>
                          <p className="text-gray-400">
                            by {data.featuredNFT.creator?.username || "CyberArtist"}
                          </p>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-pink-500">
                            {data.featuredNFT.price ? `${parseFloat(data.featuredNFT.price).toFixed(1)} ETH` : "12.5 ETH"}
                          </div>
                          <div className="text-sm text-gray-400">$23,450</div>
                        </div>
                      </div>
                      
                      <div className="flex justify-between items-center pt-4 border-t border-gray-700">
                        <div className="text-sm text-gray-400 flex items-center">
                          <Play className="w-3 h-3 mr-1" />
                          Live auction
                        </div>
                        <CyberButton variant="cyber-secondary">
                          Place Bid
                        </CyberButton>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <div className="bg-surface-dark/80 rounded-2xl p-8 text-center border border-gray-700">
                  <div className="text-gray-400">No featured NFT available</div>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-surface-dark/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-cyber text-cyan-400 mb-4">
              Why Choose BUChain?
            </h2>
            <p className="text-xl text-gray-300">
              Built with cutting-edge technology for the future of digital commerce
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index} className="bg-surface-blue/30 border-gray-700 hover:border-cyan-400/50 transition-all duration-300 nft-card">
                  <CardContent className="p-6 text-center">
                    <div className={`w-16 h-16 mx-auto mb-4 rounded-xl bg-gradient-to-br ${feature.color} flex items-center justify-center`}>
                      <Icon className="h-8 w-8 text-white" />
                    </div>
                    <h3 className="text-xl font-bold text-cyan-400 mb-2">
                      {feature.title}
                    </h3>
                    <p className="text-gray-400">
                      {feature.description}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Featured Collections */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-12">
            <h2 className="text-4xl font-cyber text-cyan-400">FEATURED COLLECTIONS</h2>
            <Link href="/marketplace?view=collections">
              <CyberButton variant="cyber-ghost">
                View All <ArrowRight className="ml-2 h-4 w-4" />
              </CyberButton>
            </Link>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {isLoading ? (
              Array.from({ length: 3 }).map((_, i) => (
                <NFTCardSkeleton key={i} />
              ))
            ) : data?.featuredCollections?.length ? (
              data.featuredCollections.map((collection) => (
                <Card key={collection.id} className="bg-surface-blue/30 border-gray-700 rounded-xl overflow-hidden nft-card hover:shadow-cyber transition-all duration-300">
                  <img 
                    src={collection.image || "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400"}
                    alt={collection.name}
                    className="w-full h-48 object-cover"
                  />
                  <CardContent className="p-6">
                    <h3 className="text-xl font-bold text-cyan-400 mb-2">
                      {collection.name}
                    </h3>
                    <p className="text-gray-400 mb-4">
                      {collection.description || "Digital infrastructure utilities for Web3 businesses"}
                    </p>
                    <div className="flex justify-between items-center">
                      <div className="text-sm text-gray-400">
                        <span>{collection.itemCount || 127}</span> items • Floor: 
                        <span className="text-pink-500 ml-1">
                          {collection.floorPrice ? `${parseFloat(collection.floorPrice).toFixed(1)} ETH` : "0.8 ETH"}
                        </span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <div className="w-6 h-6 bg-gradient-to-br from-cyan-400 to-pink-500 rounded-full"></div>
                        <span className="text-sm">{collection.creator?.username || "TechFounder"}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="col-span-full text-center py-12 text-gray-400">
                No featured collections available
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Live Auctions */}
      <section className="py-16 bg-surface-dark/50">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-12">
            <div>
              <h2 className="text-4xl font-cyber text-pink-500">LIVE AUCTIONS</h2>
              <div className="flex items-center space-x-2 mt-2">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                <span className="text-sm text-gray-400">
                  {data?.liveAuctions?.length || 24} Active Auctions
                </span>
              </div>
            </div>
            <Link href="/auctions">
              <CyberButton variant="cyber-ghost">
                View All <TrendingUp className="ml-2 h-4 w-4" />
              </CyberButton>
            </Link>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {isLoading ? (
              Array.from({ length: 4 }).map((_, i) => (
                <AuctionCardSkeleton key={i} />
              ))
            ) : data?.liveAuctions?.length ? (
              data.liveAuctions.slice(0, 4).map((auction) => (
                <AuctionCard 
                  key={auction.id} 
                  auction={auction}
                />
              ))
            ) : (
              <div className="col-span-full text-center py-12 text-gray-400">
                No live auctions available
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Affiliate NFTs Preview */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-cyber text-pink-500 mb-4">AFFILIATE NFTs</h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Unique business utility NFTs with embedded affiliate links. 
              Earn commissions on every referral while owning exclusive digital assets.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {isLoading ? (
              Array.from({ length: 3 }).map((_, i) => (
                <NFTCardSkeleton key={i} />
              ))
            ) : data?.affiliateNFTs?.length ? (
              data.affiliateNFTs.slice(0, 3).map((nft) => (
                <AffiliateNFTCard 
                  key={nft.id} 
                  nft={nft}
                />
              ))
            ) : (
              <div className="col-span-full text-center py-12 text-gray-400">
                No affiliate NFTs available
              </div>
            )}
          </div>

          {/* Affiliate CTA */}
          <div className="bg-gradient-to-r from-surface-dark to-surface-blue rounded-2xl p-8 cyber-border">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <h3 className="text-2xl font-bold text-cyan-400 mb-4">
                  Join the Affiliate Revolution
                </h3>
                <p className="text-gray-300 mb-6">
                  Own exclusive NFTs that generate passive income through embedded affiliate links. 
                  Track your referrals, monitor earnings, and scale your digital business.
                </p>
                <ul className="space-y-2 text-gray-300 mb-6">
                  <li className="flex items-center">
                    <Star className="h-4 w-4 text-green-400 mr-2" />
                    Real-time earnings tracking
                  </li>
                  <li className="flex items-center">
                    <Star className="h-4 w-4 text-green-400 mr-2" />
                    Automated commission payouts
                  </li>
                  <li className="flex items-center">
                    <Star className="h-4 w-4 text-green-400 mr-2" />
                    Multi-chain compatibility
                  </li>
                </ul>
                <Link href="/affiliate">
                  <CyberButton variant="cyber-secondary" glowEffect>
                    <Rocket className="mr-2 h-4 w-4" />
                    Start Earning Today
                  </CyberButton>
                </Link>
              </div>
              
              <div className="text-center">
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="bg-surface-dark/50 rounded-lg p-4">
                    <div className="text-2xl font-bold text-cyan-400">₿ 247.8</div>
                    <div className="text-sm text-gray-400">Total Earnings</div>
                  </div>
                  <div className="bg-surface-dark/50 rounded-lg p-4">
                    <div className="text-2xl font-bold text-pink-500">1,834</div>
                    <div className="text-sm text-gray-400">Active Referrals</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
