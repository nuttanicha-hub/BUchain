import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { AuctionCard } from "@/components/nft/auction-card";
import { AuctionCardSkeleton } from "@/components/ui/loading-skeleton";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { 
  Clock, 
  TrendingUp, 
  Filter, 
  Search,
  Gavel,
  ChevronLeft,
  ChevronRight,
  Calendar,
  DollarSign
} from "lucide-react";
import { Auction, NFT } from "@shared/schema";
import { useAuctionStore } from "@/store/auctionStore";

interface AuctionFilters {
  status: string;
  type: string;
  sortBy: string;
  search: string;
  priceRange: string;
}

interface AuctionsResponse {
  auctions: (Auction & {
    nft: NFT & {
      creator?: { username: string };
    };
    highestBidder?: { username: string };
  })[];
  total: number;
  page: number;
  totalPages: number;
}

export default function Auctions() {
  const [filters, setFilters] = useState<AuctionFilters>({
    status: "active",
    type: "all",
    sortBy: "ending_soon",
    search: "",
    priceRange: "all",
  });
  const [currentPage, setCurrentPage] = useState(1);
  const [showFilters, setShowFilters] = useState(false);
  const limit = 12;

  const { initializeSocket } = useAuctionStore();

  // Initialize WebSocket for real-time auction updates
  useEffect(() => {
    initializeSocket();
  }, [initializeSocket]);

  // Fetch auctions
  const { data, isLoading, error } = useQuery<AuctionsResponse>({
    queryKey: ['/api/auctions', filters, currentPage, limit],
    queryFn: async () => {
      const params = new URLSearchParams({
        page: currentPage.toString(),
        limit: limit.toString(),
        status: filters.status,
        type: filters.type,
        sortBy: filters.sortBy,
        ...(filters.search && { search: filters.search }),
        ...(filters.priceRange !== "all" && { priceRange: filters.priceRange }),
      });

      const response = await fetch(`/api/auctions?${params}`);
      if (!response.ok) {
        throw new Error('Failed to fetch auctions');
      }
      return response.json();
    },
  });

  const handleFilterChange = (key: keyof AuctionFilters, value: string) => {
    setFilters(prev => ({ ...prev, [key]: value }));
    setCurrentPage(1);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setCurrentPage(1);
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const filterOptions = {
    status: [
      { value: "active", label: "Active Auctions" },
      { value: "ending_soon", label: "Ending Soon" },
      { value: "completed", label: "Completed" },
      { value: "all", label: "All Auctions" },
    ],
    type: [
      { value: "all", label: "All Types" },
      { value: "english", label: "English Auction" },
      { value: "dutch", label: "Dutch Auction" },
    ],
    sortBy: [
      { value: "ending_soon", label: "Ending Soon" },
      { value: "newest", label: "Newest First" },
      { value: "price_high", label: "Highest Price" },
      { value: "price_low", label: "Lowest Price" },
      { value: "most_bids", label: "Most Bids" },
    ],
    priceRange: [
      { value: "all", label: "All Prices" },
      { value: "0-1", label: "0 - 1 ETH" },
      { value: "1-5", label: "1 - 5 ETH" },
      { value: "5-10", label: "5 - 10 ETH" },
      { value: "10+", label: "10+ ETH" },
    ],
  };

  const renderPagination = () => {
    if (!data || data.totalPages <= 1) return null;

    const pages = [];
    const maxVisiblePages = 5;
    const startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
    const endPage = Math.min(data.totalPages, startPage + maxVisiblePages - 1);

    for (let i = startPage; i <= endPage; i++) {
      pages.push(i);
    }

    return (
      <div className="flex justify-center items-center space-x-2 mt-12">
        <Button
          onClick={() => handlePageChange(currentPage - 1)}
          disabled={currentPage === 1}
          variant="outline"
          size="sm"
          className="border-gray-600 text-gray-400 hover:border-cyan-400 hover:text-cyan-400"
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>

        {pages.map(page => (
          <Button
            key={page}
            onClick={() => handlePageChange(page)}
            variant={currentPage === page ? "default" : "outline"}
            size="sm"
            className={
              currentPage === page
                ? "bg-cyan-400 text-black hover:bg-cyan-500"
                : "border-gray-600 text-gray-400 hover:border-cyan-400 hover:text-cyan-400"
            }
          >
            {page}
          </Button>
        ))}

        <Button
          onClick={() => handlePageChange(currentPage + 1)}
          disabled={currentPage === data.totalPages}
          variant="outline"
          size="sm"
          className="border-gray-600 text-gray-400 hover:border-cyan-400 hover:text-cyan-400"
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-space-dark text-white pt-24">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center space-x-4 mb-4">
            <h1 className="text-4xl lg:text-6xl font-cyber text-pink-500">
              LIVE AUCTIONS
            </h1>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
              <Badge className="bg-green-400/20 text-green-400 border border-green-400/30">
                {data?.total || 0} Active
              </Badge>
            </div>
          </div>
          <p className="text-xl text-gray-300">
            Participate in live auctions and bid on exclusive digital business utilities
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-green-400/20 to-green-400/5 border-green-400/30">
            <CardContent className="p-4 text-center">
              <Clock className="h-8 w-8 text-green-400 mx-auto mb-2" />
              <div className="text-2xl font-bold text-green-400">
                {data?.auctions?.filter(a => a.isActive).length || 0}
              </div>
              <div className="text-sm text-gray-400">Live Auctions</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-pink-500/20 to-pink-500/5 border-pink-500/30">
            <CardContent className="p-4 text-center">
              <Gavel className="h-8 w-8 text-pink-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-pink-500">247</div>
              <div className="text-sm text-gray-400">Total Bids Today</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-cyan-400/20 to-cyan-400/5 border-cyan-400/30">
            <CardContent className="p-4 text-center">
              <DollarSign className="h-8 w-8 text-cyan-400 mx-auto mb-2" />
              <div className="text-2xl font-bold text-cyan-400">892.3 ETH</div>
              <div className="text-sm text-gray-400">Volume 24h</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-500/20 to-purple-500/5 border-purple-500/30">
            <CardContent className="p-4 text-center">
              <Calendar className="h-8 w-8 text-purple-500 mx-auto mb-2" />
              <div className="text-2xl font-bold text-purple-500">18</div>
              <div className="text-sm text-gray-400">Ending Soon</div>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filters */}
        <Card className="bg-surface-blue/30 border-gray-700 mb-8">
          <CardContent className="p-6">
            <div className="flex flex-col lg:flex-row gap-4 items-center">
              {/* Search */}
              <form onSubmit={handleSearch} className="flex-1 max-w-md">
                <div className="relative">
                  <Input
                    type="text"
                    placeholder="Search auctions..."
                    value={filters.search}
                    onChange={(e) => handleFilterChange("search", e.target.value)}
                    className="bg-surface-dark border-gray-600 pl-10"
                  />
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                </div>
              </form>

              {/* Filters Toggle (Mobile) */}
              <Button
                onClick={() => setShowFilters(!showFilters)}
                variant="outline"
                className="lg:hidden border-cyan-400 text-cyan-400"
              >
                <Filter className="h-4 w-4 mr-2" />
                Filters
              </Button>

              {/* Desktop Filters */}
              <div className={`flex flex-wrap gap-4 ${showFilters ? "block" : "hidden lg:flex"}`}>
                <Select 
                  value={filters.status} 
                  onValueChange={(value) => handleFilterChange("status", value)}
                >
                  <SelectTrigger className="w-40 bg-surface-dark border-gray-600">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {filterOptions.status.map(option => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select 
                  value={filters.type} 
                  onValueChange={(value) => handleFilterChange("type", value)}
                >
                  <SelectTrigger className="w-40 bg-surface-dark border-gray-600">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {filterOptions.type.map(option => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select 
                  value={filters.priceRange} 
                  onValueChange={(value) => handleFilterChange("priceRange", value)}
                >
                  <SelectTrigger className="w-40 bg-surface-dark border-gray-600">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {filterOptions.priceRange.map(option => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select 
                  value={filters.sortBy} 
                  onValueChange={(value) => handleFilterChange("sortBy", value)}
                >
                  <SelectTrigger className="w-40 bg-surface-dark border-gray-600">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {filterOptions.sortBy.map(option => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Results Info */}
        <div className="flex justify-between items-center mb-6">
          <div className="text-gray-400">
            {isLoading ? (
              "Loading auctions..."
            ) : data ? (
              `Found ${data.total.toLocaleString()} auctions`
            ) : (
              "No auctions found"
            )}
          </div>
          
          {data && data.total > 0 && (
            <div className="text-sm text-gray-400">
              Page {currentPage} of {data.totalPages}
            </div>
          )}
        </div>

        {/* Auctions Grid */}
        {error ? (
          <div className="text-center py-12">
            <div className="text-red-400 text-lg mb-4">Failed to load auctions</div>
            <p className="text-gray-400">Please try again later</p>
          </div>
        ) : isLoading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {Array.from({ length: limit }).map((_, index) => (
              <AuctionCardSkeleton key={index} />
            ))}
          </div>
        ) : data && data.auctions.length > 0 ? (
          <>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {data.auctions.map((auction) => (
                <AuctionCard 
                  key={auction.id} 
                  auction={auction}
                />
              ))}
            </div>
            {renderPagination()}
          </>
        ) : (
          <div className="text-center py-16">
            <Gavel className="h-16 w-16 text-gray-600 mx-auto mb-4" />
            <div className="text-gray-400 text-lg mb-4">No auctions found</div>
            <p className="text-gray-500 mb-8">
              {filters.search ? 
                "Try adjusting your search terms or filters" : 
                "Be the first to start an auction!"
              }
            </p>
            <Button
              onClick={() => setFilters({
                status: "active",
                type: "all",
                sortBy: "ending_soon",
                search: "",
                priceRange: "all",
              })}
              variant="outline"
              className="border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-black"
            >
              Clear Filters
            </Button>
          </div>
        )}

        {/* Bottom CTA */}
        <div className="mt-16">
          <Card className="bg-gradient-to-r from-surface-blue/30 to-surface-dark/30 border-cyan-400/30">
            <CardContent className="p-8 text-center">
              <h3 className="text-2xl font-bold text-cyan-400 mb-4">
                Want to start your own auction?
              </h3>
              <p className="text-gray-300 mb-6">
                Create and list your digital business utilities for auction. 
                Set reserve prices and let the community decide the value.
              </p>
              <Button className="bg-gradient-to-r from-cyan-400 to-pink-500 text-black font-bold hover:shadow-cyber transition-all duration-300">
                <TrendingUp className="mr-2 h-4 w-4" />
                Start Auction
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
