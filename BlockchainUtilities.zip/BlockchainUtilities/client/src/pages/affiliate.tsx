import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { AffiliateNFTCard } from "@/components/affiliate/affiliate-nft-card";
import { NFTCardSkeleton } from "@/components/ui/loading-skeleton";
import { GlitchText } from "@/components/ui/glitch-text";
import { CyberButton } from "@/components/ui/cyber-button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { 
  Percent, 
  TrendingUp, 
  Users, 
  DollarSign,
  Search,
  Filter,
  Star,
  Rocket,
  ChevronLeft,
  ChevronRight,
  BarChart3,
  Target,
  Zap
} from "lucide-react";
import { NFT, AffiliateTracking } from "@shared/schema";
import { useWeb3Store } from "@/store/web3Store";
import { useToast } from "@/hooks/use-toast";

interface AffiliateData {
  stats: {
    totalEarnings: string;
    activeReferrals: number;
    conversionRate: number;
    topPerformer: string;
  };
  affiliateNFTs: (NFT & {
    creator?: { username: string };
    affiliateTracking?: AffiliateTracking;
  })[];
  total: number;
  userEarnings?: {
    totalEarned: string;
    monthlyEarned: string;
    referralCount: number;
    topNFT: string;
  };
}

interface AffiliateFilters {
  sortBy: string;
  category: string;
  commissionRange: string;
  search: string;
}

export default function Affiliate() {
  const [filters, setFilters] = useState<AffiliateFilters>({
    sortBy: "commission_desc",
    category: "all",
    commissionRange: "all",
    search: "",
  });
  const [currentPage, setCurrentPage] = useState(1);
  const [showFilters, setShowFilters] = useState(false);
  const limit = 12;

  const { walletInfo } = useWeb3Store();
  const { toast } = useToast();

  const { data, isLoading, error } = useQuery<AffiliateData>({
    queryKey: ['/api/affiliate/nfts', filters, currentPage, limit],
    queryFn: async () => {
      const params = new URLSearchParams({
        page: currentPage.toString(),
        limit: limit.toString(),
        sortBy: filters.sortBy,
        category: filters.category,
        commissionRange: filters.commissionRange,
        ...(filters.search && { search: filters.search }),
        ...(walletInfo?.address && { userAddress: walletInfo.address }),
      });

      const response = await fetch(`/api/affiliate/nfts?${params}`);
      if (!response.ok) {
        throw new Error('Failed to fetch affiliate NFTs');
      }
      return response.json();
    },
  });

  const handleFilterChange = (key: keyof AffiliateFilters, value: string) => {
    setFilters(prev => ({ ...prev, [key]: value }));
    setCurrentPage(1);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setCurrentPage(1);
  };

  const handlePurchaseNFT = async (nft: NFT) => {
    try {
      if (!walletInfo) {
        toast({
          title: "Wallet not connected",
          description: "Please connect your wallet to purchase NFTs",
          variant: "destructive",
        });
        return;
      }

      // Implement purchase logic here
      toast({
        title: "Purchase initiated",
        description: `Starting purchase process for ${nft.name}`,
      });
    } catch (error: any) {
      toast({
        title: "Purchase failed",
        description: error.message || "Failed to purchase NFT",
        variant: "destructive",
      });
    }
  };

  const handleShareNFT = async (nft: NFT) => {
    if (!nft.affiliateUrl || !walletInfo) return;
    
    const affiliateLink = `${nft.affiliateUrl}?ref=${walletInfo.address}&nft=${nft.id}`;
    
    try {
      if (navigator.share) {
        await navigator.share({
          title: `Check out ${nft.name} on BUChain`,
          text: `Earn ${nft.affiliateCommission}% commission by promoting this NFT!`,
          url: affiliateLink,
        });
      } else {
        await navigator.clipboard.writeText(affiliateLink);
        toast({
          title: "Link copied!",
          description: "Affiliate link copied to clipboard",
        });
      }
    } catch (error) {
      toast({
        title: "Share failed",
        description: "Unable to share affiliate link",
        variant: "destructive",
      });
    }
  };

  const filterOptions = {
    sortBy: [
      { value: "commission_desc", label: "Highest Commission" },
      { value: "commission_asc", label: "Lowest Commission" },
      { value: "price_desc", label: "Highest Price" },
      { value: "price_asc", label: "Lowest Price" },
      { value: "popular", label: "Most Popular" },
      { value: "newest", label: "Newest" },
    ],
    category: [
      { value: "all", label: "All Categories" },
      { value: "business-tools", label: "Business Tools" },
      { value: "analytics", label: "Analytics" },
      { value: "marketing", label: "Marketing" },
      { value: "automation", label: "Automation" },
      { value: "security", label: "Security" },
    ],
    commissionRange: [
      { value: "all", label: "All Commissions" },
      { value: "1-10", label: "1% - 10%" },
      { value: "10-20", label: "10% - 20%" },
      { value: "20-30", label: "20% - 30%" },
      { value: "30+", label: "30%+" },
    ],
  };

  const renderPagination = () => {
    if (!data || !data.total || Math.ceil(data.total / limit) <= 1) return null;

    const totalPages = Math.ceil(data.total / limit);
    const pages = [];
    const maxVisiblePages = 5;
    const startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
    const endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);

    for (let i = startPage; i <= endPage; i++) {
      pages.push(i);
    }

    return (
      <div className="flex justify-center items-center space-x-2 mt-12">
        <Button
          onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
          disabled={currentPage === 1}
          variant="outline"
          size="sm"
          className="border-gray-600 text-gray-400 hover:border-cyan-400 hover:text-cyan-400"
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>

        {pages.map(page => (
          <Button
            key={page}
            onClick={() => setCurrentPage(page)}
            variant={currentPage === page ? "default" : "outline"}
            size="sm"
            className={
              currentPage === page
                ? "bg-cyan-400 text-black hover:bg-cyan-500"
                : "border-gray-600 text-gray-400 hover:border-cyan-400 hover:text-cyan-400"
            }
          >
            {page}
          </Button>
        ))}

        <Button
          onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
          disabled={currentPage === totalPages}
          variant="outline"
          size="sm"
          className="border-gray-600 text-gray-400 hover:border-cyan-400 hover:text-cyan-400"
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-space-dark text-white pt-24">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <GlitchText 
            text="AFFILIATE NFTs"
            className="text-4xl lg:text-6xl font-cyber text-pink-500 mb-4"
          />
          <p className="text-xl text-gray-300 max-w-4xl mx-auto">
            Unique business utility NFTs with embedded affiliate links. 
            Earn commissions on every referral while owning exclusive digital assets.
          </p>
        </div>

        {/* Stats Overview */}
        <div className="grid md:grid-cols-4 gap-6 mb-12">
          <Card className="bg-gradient-to-br from-cyan-400/20 to-cyan-400/5 border-cyan-400/30">
            <CardContent className="p-6 text-center">
              <DollarSign className="h-8 w-8 text-cyan-400 mx-auto mb-3" />
              <div className="text-2xl font-bold text-cyan-400">
                ₿ {data?.stats.totalEarnings || "247.8"}
              </div>
              <div className="text-sm text-gray-400">Total Earnings</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-pink-500/20 to-pink-500/5 border-pink-500/30">
            <CardContent className="p-6 text-center">
              <Users className="h-8 w-8 text-pink-500 mx-auto mb-3" />
              <div className="text-2xl font-bold text-pink-500">
                {data?.stats.activeReferrals?.toLocaleString() || "1,834"}
              </div>
              <div className="text-sm text-gray-400">Active Referrals</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-400/20 to-green-400/5 border-green-400/30">
            <CardContent className="p-6 text-center">
              <Target className="h-8 w-8 text-green-400 mx-auto mb-3" />
              <div className="text-2xl font-bold text-green-400">
                {data?.stats.conversionRate || "12.4"}%
              </div>
              <div className="text-sm text-gray-400">Conversion Rate</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-500/20 to-purple-500/5 border-purple-500/30">
            <CardContent className="p-6 text-center">
              <Star className="h-8 w-8 text-purple-500 mx-auto mb-3" />
              <div className="text-2xl font-bold text-purple-500">
                {data?.stats.topPerformer || "Analytics Pro"}
              </div>
              <div className="text-sm text-gray-400">Top Performer</div>
            </CardContent>
          </Card>
        </div>

        {/* User Earnings Dashboard */}
        {walletInfo && data?.userEarnings && (
          <Card className="bg-gradient-to-r from-surface-blue/30 to-surface-dark/30 border-cyan-400/30 mb-12">
            <CardHeader>
              <CardTitle className="text-2xl font-cyber text-cyan-400 flex items-center">
                <BarChart3 className="h-6 w-6 mr-3" />
                YOUR AFFILIATE PERFORMANCE
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-4 gap-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-400">
                    {data.userEarnings.totalEarned} ETH
                  </div>
                  <div className="text-sm text-gray-400">Total Earned</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-cyan-400">
                    {data.userEarnings.monthlyEarned} ETH
                  </div>
                  <div className="text-sm text-gray-400">This Month</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-pink-500">
                    {data.userEarnings.referralCount}
                  </div>
                  <div className="text-sm text-gray-400">Your Referrals</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-purple-400">
                    {data.userEarnings.topNFT}
                  </div>
                  <div className="text-sm text-gray-400">Best Performer</div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* How it Works */}
        <Card className="bg-surface-blue/30 border-gray-700 mb-12">
          <CardHeader>
            <CardTitle className="text-2xl font-cyber text-cyan-400 text-center">
              HOW AFFILIATE NFTs WORK
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-cyan-400 to-green-400 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <span className="text-black font-bold text-xl">1</span>
                </div>
                <h3 className="text-lg font-bold text-cyan-400 mb-2">Purchase & Own</h3>
                <p className="text-gray-400 text-sm">
                  Buy an affiliate-enabled NFT and become the owner of a unique digital business utility
                </p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-pink-500 to-purple-500 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <span className="text-white font-bold text-xl">2</span>
                </div>
                <h3 className="text-lg font-bold text-pink-500 mb-2">Share & Promote</h3>
                <p className="text-gray-400 text-sm">
                  Share your unique affiliate link across social media, websites, or directly with contacts
                </p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-green-400 to-cyan-500 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <span className="text-black font-bold text-xl">3</span>
                </div>
                <h3 className="text-lg font-bold text-green-400 mb-2">Earn Commission</h3>
                <p className="text-gray-400 text-sm">
                  Receive automatic commission payments in ETH for every successful referral
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Search and Filters */}
        <Card className="bg-surface-blue/30 border-gray-700 mb-8">
          <CardContent className="p-6">
            <div className="flex flex-col lg:flex-row gap-4 items-center">
              {/* Search */}
              <form onSubmit={handleSearch} className="flex-1 max-w-md">
                <div className="relative">
                  <Input
                    type="text"
                    placeholder="Search affiliate NFTs..."
                    value={filters.search}
                    onChange={(e) => handleFilterChange("search", e.target.value)}
                    className="bg-surface-dark border-gray-600 pl-10"
                  />
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                </div>
              </form>

              {/* Filters Toggle (Mobile) */}
              <Button
                onClick={() => setShowFilters(!showFilters)}
                variant="outline"
                className="lg:hidden border-cyan-400 text-cyan-400"
              >
                <Filter className="h-4 w-4 mr-2" />
                Filters
              </Button>

              {/* Desktop Filters */}
              <div className={`flex flex-wrap gap-4 ${showFilters ? "block" : "hidden lg:flex"}`}>
                <Select 
                  value={filters.sortBy} 
                  onValueChange={(value) => handleFilterChange("sortBy", value)}
                >
                  <SelectTrigger className="w-48 bg-surface-dark border-gray-600">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {filterOptions.sortBy.map(option => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select 
                  value={filters.category} 
                  onValueChange={(value) => handleFilterChange("category", value)}
                >
                  <SelectTrigger className="w-40 bg-surface-dark border-gray-600">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {filterOptions.category.map(option => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select 
                  value={filters.commissionRange} 
                  onValueChange={(value) => handleFilterChange("commissionRange", value)}
                >
                  <SelectTrigger className="w-40 bg-surface-dark border-gray-600">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {filterOptions.commissionRange.map(option => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Results Info */}
        <div className="flex justify-between items-center mb-6">
          <div className="text-gray-400">
            {isLoading ? (
              "Loading affiliate NFTs..."
            ) : data ? (
              `Found ${data.total?.toLocaleString() || 0} affiliate NFTs`
            ) : (
              "No affiliate NFTs found"
            )}
          </div>
        </div>

        {/* NFTs Grid */}
        {error ? (
          <div className="text-center py-12">
            <div className="text-red-400 text-lg mb-4">Failed to load affiliate NFTs</div>
            <p className="text-gray-400">Please try again later</p>
          </div>
        ) : isLoading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {Array.from({ length: limit }).map((_, index) => (
              <NFTCardSkeleton key={index} />
            ))}
          </div>
        ) : data && data.affiliateNFTs.length > 0 ? (
          <>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
              {data.affiliateNFTs.map((nft) => (
                <AffiliateNFTCard
                  key={nft.id}
                  nft={nft}
                  onPurchase={handlePurchaseNFT}
                  onShare={handleShareNFT}
                  userAddress={walletInfo?.address}
                />
              ))}
            </div>
            {renderPagination()}
          </>
        ) : (
          <div className="text-center py-16">
            <Percent className="h-16 w-16 text-gray-600 mx-auto mb-4" />
            <div className="text-gray-400 text-lg mb-4">No affiliate NFTs found</div>
            <p className="text-gray-500 mb-8">
              {filters.search ? 
                "Try adjusting your search terms or filters" : 
                "Be the first to create an affiliate NFT!"
              }
            </p>
            <Button
              onClick={() => setFilters({
                sortBy: "commission_desc",
                category: "all",
                commissionRange: "all",
                search: "",
              })}
              variant="outline"
              className="border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-black"
            >
              Clear Filters
            </Button>
          </div>
        )}

        {/* Join Program CTA */}
        <div className="mt-16">
          <Card className="bg-gradient-to-r from-surface-dark to-surface-blue border-cyan-400/30 cyber-border">
            <CardContent className="p-8">
              <div className="grid md:grid-cols-2 gap-8 items-center">
                <div>
                  <h3 className="text-2xl font-bold text-cyan-400 mb-4 flex items-center">
                    <Rocket className="h-6 w-6 mr-3" />
                    JOIN THE AFFILIATE REVOLUTION
                  </h3>
                  <p className="text-gray-300 mb-6">
                    Own exclusive NFTs that generate passive income through embedded affiliate links. 
                    Track your referrals, monitor earnings, and scale your digital business with cutting-edge Web3 technology.
                  </p>
                  <ul className="space-y-2 text-gray-300 mb-6">
                    <li className="flex items-center">
                      <Zap className="h-4 w-4 text-green-400 mr-2" />
                      Real-time earnings tracking
                    </li>
                    <li className="flex items-center">
                      <Zap className="h-4 w-4 text-green-400 mr-2" />
                      Automated commission payouts
                    </li>
                    <li className="flex items-center">
                      <Zap className="h-4 w-4 text-green-400 mr-2" />
                      Multi-chain compatibility
                    </li>
                    <li className="flex items-center">
                      <Zap className="h-4 w-4 text-green-400 mr-2" />
                      Advanced analytics dashboard
                    </li>
                  </ul>
                  <CyberButton 
                    variant="cyber-secondary" 
                    glowEffect
                    className="mr-4"
                  >
                    <Rocket className="mr-2 h-4 w-4" />
                    Start Earning Today
                  </CyberButton>
                </div>
                
                <div className="text-center">
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="bg-surface-dark/50 rounded-lg p-4">
                      <div className="text-2xl font-bold text-cyan-400">
                        ₿ {data?.stats.totalEarnings || "247.8"}
                      </div>
                      <div className="text-sm text-gray-400">Total Earnings</div>
                    </div>
                    <div className="bg-surface-dark/50 rounded-lg p-4">
                      <div className="text-2xl font-bold text-pink-500">
                        {data?.stats.activeReferrals?.toLocaleString() || "1,834"}
                      </div>
                      <div className="text-sm text-gray-400">Active Referrals</div>
                    </div>
                  </div>
                  <Badge className="bg-gradient-to-r from-cyan-400 to-green-400 text-black px-4 py-2 text-sm font-bold">
                    Join 15,000+ Affiliates
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
