import { UserDashboard } from "@/components/dashboard/user-dashboard";

export default function Dashboard() {
  return <UserDashboard />;
}
