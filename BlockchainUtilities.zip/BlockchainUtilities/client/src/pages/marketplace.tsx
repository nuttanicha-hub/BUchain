import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { MarketplaceFilters } from "@/components/marketplace/marketplace-filters";
import { MarketplaceGrid } from "@/components/marketplace/marketplace-grid";

interface FilterState {
  categories: string[];
  priceRange: [number, number];
  chains: string[];
  status: string;
  hasAffiliate: boolean;
  sortBy: string;
  search?: string;
}

export default function Marketplace() {
  const [location] = useLocation();
  const [filters, setFilters] = useState<FilterState>({
    categories: [],
    priceRange: [0, 100],
    chains: [],
    status: "all",
    hasAffiliate: false,
    sortBy: "created_desc",
    search: "",
  });

  // Parse URL parameters on mount
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const search = urlParams.get("search");
    const categories = urlParams.get("categories")?.split(",").filter(Boolean) || [];
    const chains = urlParams.get("chains")?.split(",").filter(Boolean) || [];
    const status = urlParams.get("status") || "all";
    const sortBy = urlParams.get("sort") || "created_desc";
    const hasAffiliate = urlParams.get("affiliate") === "true";
    
    setFilters(prev => ({
      ...prev,
      search: search || "",
      categories,
      chains,
      status,
      sortBy,
      hasAffiliate,
    }));
  }, [location]);

  const handleFiltersChange = (newFilters: FilterState) => {
    setFilters(newFilters);
    
    // Update URL parameters
    const params = new URLSearchParams();
    if (newFilters.search) params.set("search", newFilters.search);
    if (newFilters.categories.length > 0) params.set("categories", newFilters.categories.join(","));
    if (newFilters.chains.length > 0) params.set("chains", newFilters.chains.join(","));
    if (newFilters.status !== "all") params.set("status", newFilters.status);
    if (newFilters.sortBy !== "created_desc") params.set("sort", newFilters.sortBy);
    if (newFilters.hasAffiliate) params.set("affiliate", "true");
    if (newFilters.priceRange[0] > 0) params.set("minPrice", newFilters.priceRange[0].toString());
    if (newFilters.priceRange[1] < 100) params.set("maxPrice", newFilters.priceRange[1].toString());
    
    const newUrl = params.toString() ? `${location}?${params.toString()}` : location;
    window.history.replaceState({}, "", newUrl);
  };

  const handleClearFilters = () => {
    const clearedFilters: FilterState = {
      categories: [],
      priceRange: [0, 100],
      chains: [],
      status: "all",
      hasAffiliate: false,
      sortBy: "created_desc",
      search: "",
    };
    
    setFilters(clearedFilters);
    window.history.replaceState({}, "", location);
  };

  return (
    <div className="min-h-screen bg-space-dark text-white pt-24">
      <div className="container mx-auto px-4 py-8">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-4xl lg:text-6xl font-cyber text-cyan-400 mb-4">
            MARKETPLACE
          </h1>
          <p className="text-xl text-gray-300">
            Discover, collect, and trade digital business utilities from creators worldwide
          </p>
        </div>

        {/* Main Content */}
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters Sidebar */}
          <div className="lg:w-64 flex-shrink-0">
            <MarketplaceFilters
              filters={filters}
              onFiltersChange={handleFiltersChange}
              onClearFilters={handleClearFilters}
            />
          </div>

          {/* NFT Grid */}
          <MarketplaceGrid
            filters={filters}
            onFiltersChange={handleFiltersChange}
          />
        </div>
      </div>
    </div>
  );
}
