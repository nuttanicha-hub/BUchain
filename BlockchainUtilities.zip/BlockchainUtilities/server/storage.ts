import { 
  users, 
  nfts, 
  auctions, 
  bids, 
  affiliateTracking, 
  transactions, 
  collections,
  type User, 
  type InsertUser,
  type NFT,
  type InsertNFT,
  type Auction,
  type InsertAuction,
  type Bid,
  type InsertBid,
  type AffiliateTracking,
  type Transaction,
  type Collection
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByWalletAddress(walletAddress: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // NFTs
  getNFT(id: number): Promise<NFT | undefined>;
  createNFT(nft: InsertNFT): Promise<NFT>;
  getUserNFTs(userId: number, options?: { limit?: number }): Promise<NFT[]>;
  getMarketplaceNFTs(options: {
    page: number;
    limit: number;
    sortBy: string;
    filters?: {
      categories?: string[];
      chains?: string[];
      minPrice?: number;
      maxPrice?: number;
      status?: string;
      hasAffiliate?: boolean;
      search?: string;
    };
  }): Promise<{
    nfts: (NFT & { creator?: { username: string }; owner?: { username: string } })[];
    total: number;
    page: number;
    limit: number;
    totalPages: number;
  }>;
  getTrendingNFTs(limit: number): Promise<NFT[]>;
  getFeaturedNFT(): Promise<NFT | undefined>;

  // Collections
  getFeaturedCollections(limit: number): Promise<Collection[]>;

  // Auctions
  getAuction(id: number): Promise<Auction | undefined>;
  createAuction(auction: InsertAuction): Promise<Auction>;
  updateAuction(id: number, updates: Partial<Auction>): Promise<void>;
  getAuctions(options: {
    page: number;
    limit: number;
    sortBy: string;
    filters?: {
      status?: string;
      type?: string;
      search?: string;
      priceRange?: string;
    };
  }): Promise<{
    auctions: (Auction & {
      nft: NFT & { creator?: { username: string } };
      highestBidder?: { username: string };
    })[];
    total: number;
    page: number;
    totalPages: number;
  }>;
  getLiveAuctions(limit: number): Promise<(Auction & {
    nft: NFT & { creator?: { username: string } };
    highestBidder?: { username: string };
  })[]>;

  // Bids
  createBid(bid: InsertBid): Promise<Bid>;

  // Affiliate
  getAffiliateNFTs(options: {
    page?: number;
    limit?: number;
    sortBy?: string;
    filters?: {
      category?: string;
      commissionRange?: string;
      search?: string;
    };
  }): Promise<{
    nfts: (NFT & {
      creator?: { username: string };
      affiliateTracking?: AffiliateTracking;
    })[];
    total: number;
  }>;
  getAffiliateStats(): Promise<{
    totalEarnings: string;
    activeReferrals: number;
    conversionRate: number;
    topPerformer: string;
  }>;
  getUserAffiliateEarnings(userId: number): Promise<{
    totalEarned: string;
    monthlyEarned: string;
    referralCount: number;
    topNFT: string;
  }>;

  // Dashboard
  getUserStats(userId: number): Promise<{
    ownedNFTs: number;
    createdNFTs: number;
    totalEarnings: string;
    activeBids: number;
    affiliateEarnings: string;
    affiliateReferrals: number;
    monthlyChange: {
      earnings: number;
      nfts: number;
      bids: number;
    };
  }>;
  getUserActivity(userId: number, options: { limit: number }): Promise<Transaction[]>;

  // Stats
  getMarketplaceStats(): Promise<{
    totalNFTs: string;
    totalVolume: string;
    activeUsers: string;
  }>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private nfts: Map<number, NFT>;
  private auctions: Map<number, Auction>;
  private bids: Map<number, Bid>;
  private collections: Map<number, Collection>;
  private affiliateTracking: Map<number, AffiliateTracking>;
  private transactions: Map<number, Transaction>;
  private currentId: number;

  constructor() {
    this.users = new Map();
    this.nfts = new Map();
    this.auctions = new Map();
    this.bids = new Map();
    this.collections = new Map();
    this.affiliateTracking = new Map();
    this.transactions = new Map();
    this.currentId = 1;

    // Initialize with some sample data structure (empty but ready)
    this.initializeEmptyData();
  }

  private initializeEmptyData() {
    // This creates the structure but doesn't add any sample data
    // The frontend will handle empty states appropriately
  }

  private getNextId(): number {
    return this.currentId++;
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async getUserByWalletAddress(walletAddress: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.walletAddress === walletAddress,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.getNextId();
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt: new Date().toISOString(),
      isVerified: false,
    };
    this.users.set(id, user);
    return user;
  }

  // NFTs
  async getNFT(id: number): Promise<NFT | undefined> {
    return this.nfts.get(id);
  }

  async createNFT(insertNFT: InsertNFT): Promise<NFT> {
    const id = this.getNextId();
    const nft: NFT = {
      ...insertNFT,
      id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.nfts.set(id, nft);
    return nft;
  }

  async getUserNFTs(userId: number, options?: { limit?: number }): Promise<NFT[]> {
    const userNFTs = Array.from(this.nfts.values())
      .filter(nft => nft.ownerId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    
    return options?.limit ? userNFTs.slice(0, options.limit) : userNFTs;
  }

  async getMarketplaceNFTs(options: {
    page: number;
    limit: number;
    sortBy: string;
    filters?: {
      categories?: string[];
      chains?: string[];
      minPrice?: number;
      maxPrice?: number;
      status?: string;
      hasAffiliate?: boolean;
      search?: string;
    };
  }): Promise<{
    nfts: (NFT & { creator?: { username: string }; owner?: { username: string } })[];
    total: number;
    page: number;
    limit: number;
    totalPages: number;
  }> {
    let filteredNFTs = Array.from(this.nfts.values());

    // Apply filters
    if (options.filters) {
      const { categories, chains, minPrice, maxPrice, status, hasAffiliate, search } = options.filters;

      if (categories?.length) {
        filteredNFTs = filteredNFTs.filter(nft => categories.includes(nft.category));
      }

      if (chains?.length) {
        filteredNFTs = filteredNFTs.filter(nft => chains.includes(nft.chain));
      }

      if (minPrice !== undefined) {
        filteredNFTs = filteredNFTs.filter(nft => 
          nft.price && parseFloat(nft.price) >= minPrice
        );
      }

      if (maxPrice !== undefined) {
        filteredNFTs = filteredNFTs.filter(nft => 
          nft.price && parseFloat(nft.price) <= maxPrice
        );
      }

      if (status !== "all") {
        if (status === "buy_now") {
          filteredNFTs = filteredNFTs.filter(nft => nft.isListed && nft.price);
        }
      }

      if (hasAffiliate) {
        filteredNFTs = filteredNFTs.filter(nft => nft.isAffiliate);
      }

      if (search) {
        const searchLower = search.toLowerCase();
        filteredNFTs = filteredNFTs.filter(nft =>
          nft.name.toLowerCase().includes(searchLower) ||
          nft.description?.toLowerCase().includes(searchLower)
        );
      }
    }

    // Apply sorting
    switch (options.sortBy) {
      case "price_asc":
        filteredNFTs.sort((a, b) => (parseFloat(a.price || "0") - parseFloat(b.price || "0")));
        break;
      case "price_desc":
        filteredNFTs.sort((a, b) => (parseFloat(b.price || "0") - parseFloat(a.price || "0")));
        break;
      case "created_desc":
        filteredNFTs.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        break;
      case "name_asc":
        filteredNFTs.sort((a, b) => a.name.localeCompare(b.name));
        break;
    }

    const total = filteredNFTs.length;
    const totalPages = Math.ceil(total / options.limit);
    const startIndex = (options.page - 1) * options.limit;
    const endIndex = startIndex + options.limit;
    const paginatedNFTs = filteredNFTs.slice(startIndex, endIndex);

    // Add creator and owner info
    const nftsWithInfo = paginatedNFTs.map(nft => ({
      ...nft,
      creator: nft.creatorId ? this.users.get(nft.creatorId) : undefined,
      owner: nft.ownerId ? this.users.get(nft.ownerId) : undefined,
    }));

    return {
      nfts: nftsWithInfo,
      total,
      page: options.page,
      limit: options.limit,
      totalPages,
    };
  }

  async getTrendingNFTs(limit: number): Promise<NFT[]> {
    return Array.from(this.nfts.values())
      .filter(nft => nft.isListed)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, limit);
  }

  async getFeaturedNFT(): Promise<NFT | undefined> {
    const listedNFTs = Array.from(this.nfts.values()).filter(nft => nft.isListed);
    return listedNFTs[0]; // Return first listed NFT or undefined if none
  }

  // Collections
  async getFeaturedCollections(limit: number): Promise<Collection[]> {
    return Array.from(this.collections.values())
      .sort((a, b) => parseFloat(b.totalVolume || "0") - parseFloat(a.totalVolume || "0"))
      .slice(0, limit);
  }

  // Auctions
  async getAuction(id: number): Promise<Auction | undefined> {
    return this.auctions.get(id);
  }

  async createAuction(insertAuction: InsertAuction): Promise<Auction> {
    const id = this.getNextId();
    const auction: Auction = {
      ...insertAuction,
      id,
      createdAt: new Date().toISOString(),
    };
    this.auctions.set(id, auction);
    return auction;
  }

  async updateAuction(id: number, updates: Partial<Auction>): Promise<void> {
    const auction = this.auctions.get(id);
    if (auction) {
      this.auctions.set(id, { ...auction, ...updates });
    }
  }

  async getAuctions(options: {
    page: number;
    limit: number;
    sortBy: string;
    filters?: {
      status?: string;
      type?: string;
      search?: string;
      priceRange?: string;
    };
  }): Promise<{
    auctions: (Auction & {
      nft: NFT & { creator?: { username: string } };
      highestBidder?: { username: string };
    })[];
    total: number;
    page: number;
    totalPages: number;
  }> {
    let filteredAuctions = Array.from(this.auctions.values());

    // Apply filters
    if (options.filters) {
      const { status, type, search, priceRange } = options.filters;

      if (status === "active") {
        filteredAuctions = filteredAuctions.filter(auction => auction.isActive);
      } else if (status === "completed") {
        filteredAuctions = filteredAuctions.filter(auction => auction.isCompleted);
      } else if (status === "ending_soon") {
        const now = new Date();
        const oneHour = 60 * 60 * 1000;
        filteredAuctions = filteredAuctions.filter(auction => {
          const endTime = new Date(auction.endTime);
          return auction.isActive && (endTime.getTime() - now.getTime()) < oneHour;
        });
      }

      if (type) {
        filteredAuctions = filteredAuctions.filter(auction => auction.type === type);
      }

      if (search) {
        const searchLower = search.toLowerCase();
        filteredAuctions = filteredAuctions.filter(auction => {
          const nft = this.nfts.get(auction.nftId!);
          return nft && (
            nft.name.toLowerCase().includes(searchLower) ||
            nft.description?.toLowerCase().includes(searchLower)
          );
        });
      }

      if (priceRange && priceRange !== "all") {
        const [min, max] = priceRange.split("-").map(p => p === "+" ? Infinity : parseFloat(p));
        filteredAuctions = filteredAuctions.filter(auction => {
          const currentBid = parseFloat(auction.currentBid || auction.startPrice);
          return currentBid >= min && (max === Infinity || currentBid <= max);
        });
      }
    }

    // Apply sorting
    switch (options.sortBy) {
      case "ending_soon":
        filteredAuctions.sort((a, b) => 
          new Date(a.endTime).getTime() - new Date(b.endTime).getTime()
        );
        break;
      case "newest":
        filteredAuctions.sort((a, b) => 
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
        break;
      case "price_high":
        filteredAuctions.sort((a, b) => 
          parseFloat(b.currentBid || b.startPrice) - parseFloat(a.currentBid || a.startPrice)
        );
        break;
      case "price_low":
        filteredAuctions.sort((a, b) => 
          parseFloat(a.currentBid || a.startPrice) - parseFloat(b.currentBid || b.startPrice)
        );
        break;
    }

    const total = filteredAuctions.length;
    const totalPages = Math.ceil(total / options.limit);
    const startIndex = (options.page - 1) * options.limit;
    const endIndex = startIndex + options.limit;
    const paginatedAuctions = filteredAuctions.slice(startIndex, endIndex);

    // Add NFT and bidder info
    const auctionsWithInfo = paginatedAuctions.map(auction => {
      const nft = this.nfts.get(auction.nftId!);
      const creator = nft?.creatorId ? this.users.get(nft.creatorId) : undefined;
      const highestBidder = auction.highestBidderId ? this.users.get(auction.highestBidderId) : undefined;

      return {
        ...auction,
        nft: nft ? { ...nft, creator } : {} as NFT,
        highestBidder,
      };
    });

    return {
      auctions: auctionsWithInfo,
      total,
      page: options.page,
      totalPages,
    };
  }

  async getLiveAuctions(limit: number): Promise<(Auction & {
    nft: NFT & { creator?: { username: string } };
    highestBidder?: { username: string };
  })[]> {
    const result = await this.getAuctions({
      page: 1,
      limit,
      sortBy: "ending_soon",
      filters: { status: "active" },
    });
    return result.auctions;
  }

  // Bids
  async createBid(insertBid: InsertBid): Promise<Bid> {
    const id = this.getNextId();
    const bid: Bid = {
      ...insertBid,
      id,
      createdAt: new Date().toISOString(),
    };
    this.bids.set(id, bid);
    return bid;
  }

  // Affiliate
  async getAffiliateNFTs(options: {
    page?: number;
    limit?: number;
    sortBy?: string;
    filters?: {
      category?: string;
      commissionRange?: string;
      search?: string;
    };
  }): Promise<{
    nfts: (NFT & {
      creator?: { username: string };
      affiliateTracking?: AffiliateTracking;
    })[];
    total: number;
  }> {
    let affiliateNFTs = Array.from(this.nfts.values()).filter(nft => nft.isAffiliate);

    // Apply filters
    if (options.filters) {
      const { category, commissionRange, search } = options.filters;

      if (category) {
        affiliateNFTs = affiliateNFTs.filter(nft => nft.category === category);
      }

      if (commissionRange && commissionRange !== "all") {
        const [min, max] = commissionRange.split("-").map(p => 
          p === "+" ? Infinity : parseFloat(p)
        );
        affiliateNFTs = affiliateNFTs.filter(nft => {
          const commission = parseFloat(nft.affiliateCommission || "0");
          return commission >= min && (max === Infinity || commission <= max);
        });
      }

      if (search) {
        const searchLower = search.toLowerCase();
        affiliateNFTs = affiliateNFTs.filter(nft =>
          nft.name.toLowerCase().includes(searchLower) ||
          nft.description?.toLowerCase().includes(searchLower)
        );
      }
    }

    // Apply sorting
    switch (options.sortBy) {
      case "commission_desc":
        affiliateNFTs.sort((a, b) => 
          parseFloat(b.affiliateCommission || "0") - parseFloat(a.affiliateCommission || "0")
        );
        break;
      case "commission_asc":
        affiliateNFTs.sort((a, b) => 
          parseFloat(a.affiliateCommission || "0") - parseFloat(b.affiliateCommission || "0")
        );
        break;
      case "price_desc":
        affiliateNFTs.sort((a, b) => 
          parseFloat(b.price || "0") - parseFloat(a.price || "0")
        );
        break;
      case "price_asc":
        affiliateNFTs.sort((a, b) => 
          parseFloat(a.price || "0") - parseFloat(b.price || "0")
        );
        break;
      case "newest":
        affiliateNFTs.sort((a, b) => 
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
        break;
    }

    const total = affiliateNFTs.length;
    const page = options.page || 1;
    const limit = options.limit || 12;
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const paginatedNFTs = affiliateNFTs.slice(startIndex, endIndex);

    // Add creator and tracking info
    const nftsWithInfo = paginatedNFTs.map(nft => {
      const creator = nft.creatorId ? this.users.get(nft.creatorId) : undefined;
      const tracking = Array.from(this.affiliateTracking.values())
        .find(t => t.nftId === nft.id);

      return {
        ...nft,
        creator,
        affiliateTracking: tracking,
      };
    });

    return {
      nfts: nftsWithInfo,
      total,
    };
  }

  async getAffiliateStats(): Promise<{
    totalEarnings: string;
    activeReferrals: number;
    conversionRate: number;
    topPerformer: string;
  }> {
    const trackingRecords = Array.from(this.affiliateTracking.values());
    const totalEarnings = trackingRecords
      .reduce((sum, record) => sum + parseFloat(record.totalEarnings || "0"), 0)
      .toFixed(2);
    
    const activeReferrals = trackingRecords
      .reduce((sum, record) => sum + (record.conversionCount || 0), 0);

    const totalClicks = trackingRecords
      .reduce((sum, record) => sum + (record.clickCount || 0), 0);

    const conversionRate = totalClicks > 0 ? (activeReferrals / totalClicks) * 100 : 0;

    // Find top performing NFT
    const topRecord = trackingRecords
      .sort((a, b) => parseFloat(b.totalEarnings || "0") - parseFloat(a.totalEarnings || "0"))[0];
    
    const topPerformer = topRecord ? 
      this.nfts.get(topRecord.nftId!)?.name || "Unknown" : "None";

    return {
      totalEarnings,
      activeReferrals,
      conversionRate: parseFloat(conversionRate.toFixed(1)),
      topPerformer,
    };
  }

  async getUserAffiliateEarnings(userId: number): Promise<{
    totalEarned: string;
    monthlyEarned: string;
    referralCount: number;
    topNFT: string;
  }> {
    const userTracking = Array.from(this.affiliateTracking.values())
      .filter(record => record.affiliateId === userId);

    const totalEarned = userTracking
      .reduce((sum, record) => sum + parseFloat(record.totalEarnings || "0"), 0)
      .toFixed(4);

    // For monthly earnings, we'd typically filter by date, but for now return a portion
    const monthlyEarned = (parseFloat(totalEarned) * 0.3).toFixed(4);

    const referralCount = userTracking
      .reduce((sum, record) => sum + (record.conversionCount || 0), 0);

    const topRecord = userTracking
      .sort((a, b) => parseFloat(b.totalEarnings || "0") - parseFloat(a.totalEarnings || "0"))[0];
    
    const topNFT = topRecord ? 
      this.nfts.get(topRecord.nftId!)?.name || "Unknown" : "None";

    return {
      totalEarned,
      monthlyEarned,
      referralCount,
      topNFT,
    };
  }

  // Dashboard
  async getUserStats(userId: number): Promise<{
    ownedNFTs: number;
    createdNFTs: number;
    totalEarnings: string;
    activeBids: number;
    affiliateEarnings: string;
    affiliateReferrals: number;
    monthlyChange: {
      earnings: number;
      nfts: number;
      bids: number;
    };
  }> {
    const ownedNFTs = Array.from(this.nfts.values())
      .filter(nft => nft.ownerId === userId).length;

    const createdNFTs = Array.from(this.nfts.values())
      .filter(nft => nft.creatorId === userId).length;

    const userBids = Array.from(this.bids.values())
      .filter(bid => bid.bidderId === userId);

    const totalEarnings = userBids
      .reduce((sum, bid) => sum + parseFloat(bid.amount), 0)
      .toFixed(3);

    const activeBids = userBids.length;

    const affiliateEarnings = Array.from(this.affiliateTracking.values())
      .filter(record => record.affiliateId === userId)
      .reduce((sum, record) => sum + parseFloat(record.totalEarnings || "0"), 0)
      .toFixed(4);

    const affiliateReferrals = Array.from(this.affiliateTracking.values())
      .filter(record => record.affiliateId === userId)
      .reduce((sum, record) => sum + (record.conversionCount || 0), 0);

    return {
      ownedNFTs,
      createdNFTs,
      totalEarnings,
      activeBids,
      affiliateEarnings,
      affiliateReferrals,
      monthlyChange: {
        earnings: 15.2, // Mock percentage change
        nfts: 8.5,
        bids: -2.1,
      },
    };
  }

  async getUserActivity(userId: number, options: { limit: number }): Promise<Transaction[]> {
    return Array.from(this.transactions.values())
      .filter(tx => tx.fromUserId === userId || tx.toUserId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, options.limit);
  }

  // Stats
  async getMarketplaceStats(): Promise<{
    totalNFTs: string;
    totalVolume: string;
    activeUsers: string;
  }> {
    return {
      totalNFTs: this.nfts.size.toLocaleString(),
      totalVolume: "₿ " + (this.nfts.size * 0.5).toFixed(1), // Mock calculation
      activeUsers: this.users.size.toLocaleString(),
    };
  }
}

export const storage = new MemStorage();
