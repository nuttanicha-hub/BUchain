import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertNftSchema, insertAuctionSchema, insertBidSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for real-time auction updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  const activeConnections = new Map<string, Set<WebSocket>>();
  const userConnections = new Map<string, WebSocket>();

  wss.on('connection', (ws) => {
    console.log('WebSocket connection established');

    ws.on('message', (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        switch (data.type) {
          case 'join_auction':
            const auctionId = data.auctionId.toString();
            if (!activeConnections.has(auctionId)) {
              activeConnections.set(auctionId, new Set());
            }
            activeConnections.get(auctionId)!.add(ws);
            break;
            
          case 'leave_auction':
            const leaveAuctionId = data.auctionId.toString();
            if (activeConnections.has(leaveAuctionId)) {
              activeConnections.get(leaveAuctionId)!.delete(ws);
            }
            break;
            
          case 'subscribe_user':
            userConnections.set(data.userId.toString(), ws);
            break;
            
          case 'place_bid':
            // Broadcast bid update to auction participants
            const bidAuctionId = data.auctionId.toString();
            if (activeConnections.has(bidAuctionId)) {
              const auctionConnections = activeConnections.get(bidAuctionId)!;
              auctionConnections.forEach(connection => {
                if (connection.readyState === WebSocket.OPEN) {
                  connection.send(JSON.stringify({
                    type: 'auction_update',
                    auctionId: data.auctionId,
                    currentBid: data.amount,
                    bidderId: data.userId,
                    timestamp: Date.now(),
                  }));
                }
              });
            }
            break;
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      // Clean up connections
      activeConnections.forEach((connections) => {
        connections.delete(ws);
      });
      
      for (const [userId, connection] of userConnections) {
        if (connection === ws) {
          userConnections.delete(userId);
          break;
        }
      }
    });
  });

  // Helper function to broadcast to auction participants
  const broadcastToAuction = (auctionId: number, data: any) => {
    const connections = activeConnections.get(auctionId.toString());
    if (connections) {
      connections.forEach(ws => {
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify(data));
        }
      });
    }
  };

  // Home page data
  app.get("/api/home", async (req, res) => {
    try {
      const stats = await storage.getMarketplaceStats();
      const featuredNFT = await storage.getFeaturedNFT();
      const featuredCollections = await storage.getFeaturedCollections(3);
      const liveAuctions = await storage.getLiveAuctions(4);
      const trendingNFTs = await storage.getTrendingNFTs(6);
      const affiliateNFTs = await storage.getAffiliateNFTs({ limit: 3 });

      res.json({
        stats,
        featuredNFT,
        featuredCollections,
        liveAuctions,
        trendingNFTs,
        affiliateNFTs: affiliateNFTs.nfts,
      });
    } catch (error) {
      console.error("Failed to fetch home data:", error);
      res.status(500).json({ error: "Failed to fetch home data" });
    }
  });

  // Marketplace NFTs
  app.get("/api/nfts/marketplace", async (req, res) => {
    try {
      const {
        page = "1",
        limit = "12",
        categories,
        chains,
        minPrice,
        maxPrice,
        status = "all",
        hasAffiliate = "false",
        sortBy = "created_desc",
        search,
      } = req.query;

      const filters = {
        categories: categories ? (categories as string).split(',') : undefined,
        chains: chains ? (chains as string).split(',') : undefined,
        minPrice: minPrice ? parseFloat(minPrice as string) : undefined,
        maxPrice: maxPrice ? parseFloat(maxPrice as string) : undefined,
        status: status as string,
        hasAffiliate: hasAffiliate === "true",
        search: search as string,
      };

      const result = await storage.getMarketplaceNFTs({
        page: parseInt(page as string),
        limit: parseInt(limit as string),
        sortBy: sortBy as string,
        filters,
      });

      res.json(result);
    } catch (error) {
      console.error("Failed to fetch marketplace NFTs:", error);
      res.status(500).json({ error: "Failed to fetch marketplace NFTs" });
    }
  });

  // Live auctions
  app.get("/api/auctions", async (req, res) => {
    try {
      const {
        page = "1",
        limit = "12",
        status = "active",
        type = "all",
        sortBy = "ending_soon",
        search,
        priceRange,
      } = req.query;

      const filters = {
        status: status as string,
        type: type === "all" ? undefined : type as string,
        search: search as string,
        priceRange: priceRange as string,
      };

      const result = await storage.getAuctions({
        page: parseInt(page as string),
        limit: parseInt(limit as string),
        sortBy: sortBy as string,
        filters,
      });

      res.json(result);
    } catch (error) {
      console.error("Failed to fetch auctions:", error);
      res.status(500).json({ error: "Failed to fetch auctions" });
    }
  });

  // Place bid
  app.post("/api/auctions/:id/bid", async (req, res) => {
    try {
      const auctionId = parseInt(req.params.id);
      const bidSchema = insertBidSchema.extend({
        amount: z.string().min(1),
      });
      
      const { amount, bidderId, txHash } = bidSchema.parse(req.body);
      
      const auction = await storage.getAuction(auctionId);
      if (!auction) {
        return res.status(404).json({ error: "Auction not found" });
      }

      if (!auction.isActive) {
        return res.status(400).json({ error: "Auction is not active" });
      }

      const bidAmount = parseFloat(amount);
      const currentBid = parseFloat(auction.currentBid || auction.startPrice);
      
      if (bidAmount <= currentBid) {
        return res.status(400).json({ error: "Bid must be higher than current bid" });
      }

      const bid = await storage.createBid({
        auctionId,
        bidderId,
        amount,
        txHash,
      });

      // Update auction with new highest bid
      await storage.updateAuction(auctionId, {
        currentBid: amount,
        highestBidderId: bidderId,
      });

      // Broadcast to auction participants
      broadcastToAuction(auctionId, {
        type: 'bid_placed',
        auctionId,
        bid: {
          ...bid,
          bidder: await storage.getUser(bidderId),
        },
        currentBid: amount,
      });

      res.json({ success: true, bid });
    } catch (error) {
      console.error("Failed to place bid:", error);
      res.status(500).json({ error: "Failed to place bid" });
    }
  });

  // Affiliate NFTs
  app.get("/api/affiliate/nfts", async (req, res) => {
    try {
      const {
        page = "1",
        limit = "12",
        sortBy = "commission_desc",
        category = "all",
        commissionRange = "all",
        search,
        userAddress,
      } = req.query;

      const filters = {
        category: category === "all" ? undefined : category as string,
        commissionRange: commissionRange as string,
        search: search as string,
      };

      const result = await storage.getAffiliateNFTs({
        page: parseInt(page as string),
        limit: parseInt(limit as string),
        sortBy: sortBy as string,
        filters,
      });

      // Get affiliate stats
      const stats = await storage.getAffiliateStats();
      
      // Get user earnings if address provided
      let userEarnings;
      if (userAddress) {
        const user = await storage.getUserByWalletAddress(userAddress as string);
        if (user) {
          userEarnings = await storage.getUserAffiliateEarnings(user.id);
        }
      }

      res.json({
        ...result,
        stats,
        userEarnings,
      });
    } catch (error) {
      console.error("Failed to fetch affiliate NFTs:", error);
      res.status(500).json({ error: "Failed to fetch affiliate NFTs" });
    }
  });

  // User dashboard
  app.get("/api/dashboard", async (req, res) => {
    try {
      const walletAddress = req.query.walletAddress as string;
      if (!walletAddress) {
        return res.status(400).json({ error: "Wallet address required" });
      }

      const user = await storage.getUserByWalletAddress(walletAddress);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      const stats = await storage.getUserStats(user.id);
      const recentNFTs = await storage.getUserNFTs(user.id, { limit: 3 });
      const recentActivity = await storage.getUserActivity(user.id, { limit: 5 });

      res.json({
        stats,
        recentNFTs,
        recentActivity,
      });
    } catch (error) {
      console.error("Failed to fetch dashboard data:", error);
      res.status(500).json({ error: "Failed to fetch dashboard data" });
    }
  });

  // Create NFT
  app.post("/api/nfts", async (req, res) => {
    try {
      const nftData = insertNftSchema.parse(req.body);
      const nft = await storage.createNFT(nftData);
      
      res.json({ success: true, nft });
    } catch (error) {
      console.error("Failed to create NFT:", error);
      res.status(500).json({ error: "Failed to create NFT" });
    }
  });

  // Create auction
  app.post("/api/auctions", async (req, res) => {
    try {
      const auctionData = insertAuctionSchema.parse(req.body);
      const auction = await storage.createAuction(auctionData);
      
      res.json({ success: true, auction });
    } catch (error) {
      console.error("Failed to create auction:", error);
      res.status(500).json({ error: "Failed to create auction" });
    }
  });

  // Get user by wallet address
  app.get("/api/users/wallet/:address", async (req, res) => {
    try {
      const user = await storage.getUserByWalletAddress(req.params.address);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error) {
      console.error("Failed to fetch user:", error);
      res.status(500).json({ error: "Failed to fetch user" });
    }
  });

  // Create user
  app.post("/api/users", async (req, res) => {
    try {
      const { walletAddress, username, email } = req.body;
      const user = await storage.createUser({ walletAddress, username, email });
      res.json({ success: true, user });
    } catch (error) {
      console.error("Failed to create user:", error);
      res.status(500).json({ error: "Failed to create user" });
    }
  });

  return httpServer;
}
